drop  database if exists RoTen;
create database RoTen;
use RoTen;

DROP TABLE IF EXISTS utente;
CREATE TABLE utente (
idUtente smallint unsigned primary key AUTO_INCREMENT,
nome varchar (15) NOT NULL,
cognome varchar (15) NOT NULL,
email varchar (50) NOT NULL,
password char(128) NOT NULL,
admin boolean NOT NULL
);

DROP TABLE IF EXISTS categoria;
CREATE TABLE categoria (
idCategoria smallint unsigned primary key AUTO_INCREMENT,
nomeCategoria varchar(20) NOT NULL,
descrizioneCategoria text NOT NULL,
immagine varchar(255) NOT NULL
);

DROP TABLE IF EXISTS prodotto;
CREATE TABLE prodotto (
idProdotto smallint unsigned PRIMARY KEY AUTO_INCREMENT,					#smallint unsigned va da 0 a 65535, signed da -32768 a 32767
quantitaProdotto tinyint unsigned NOT NULL,
scontoProdotto tinyint unsigned,
descrizioneBreve text NOT NULL,
descrizioneDettagliata text NOT NULL,
nomeProdotto varchar(30) NOT NULL,
indicazioniUtilizzo text NOT NULL,
prezzoProdotto decimal(5,2) NOT NULL,			#5 è il numero totale di cifre sia a destra che a sinistra del punto
immagine varchar(255) NOT NULL,
categoria_fk smallint unsigned NOT NULL,
foreign key (categoria_fk) references categoria (idCategoria) on delete cascade
);

DROP TABLE IF EXISTS ordine;
CREATE TABLE ordine (
idOrdine smallint unsigned primary key AUTO_INCREMENT,
totale decimal(5,2) NOT NULL,							-- Il primo numero è il numero totale di cifre, il secondo indica il numero di cifre dopo la virgola		
dataOrdine date NOT NULL,
utente_fk smallint unsigned,
foreign key (utente_fk) references utente (idUtente) on delete cascade
);

DROP TABLE IF EXISTS datiAnagrafici;
CREATE TABLE datiAnagrafici (
titoloSociale varchar(10) NOT NULL,
citta varchar (20) NOT NULL,
via varchar (40) NOT NULL,
partitaIva char(11),
numeroCivico varchar(5) NOT NULL,
cap char(5) NOT NULL,
codiceFiscale char(16) NOT NULL UNIQUE,
utente_fk smallint unsigned NOT NULL,
primary key(utente_fk, codiceFiscale),
foreign key (utente_fk) references utente (idUtente) on delete cascade
);

DROP TABLE IF EXISTS taglia;
CREATE TABLE taglia (
idTaglia smallint unsigned primary key AUTO_INCREMENT,
tipo varchar(10) NOT NULL,
numero varchar (10)
);

DROP TABLE IF EXISTS ordine_prodotto;
CREATE TABLE ordine_prodotto (
ordine_fk smallint unsigned NOT NULL,
prodotto_fk smallint unsigned NOT NULL,
taglia_fk smallint unsigned NOT NULL,
quantita tinyint unsigned NOT NULL,
PRIMARY KEY (ordine_fk, prodotto_fk, taglia_fk),
FOREIGN KEY (taglia_fk) REFERENCES taglia (idTaglia) ON DELETE CASCADE,
FOREIGN KEY (ordine_fk) REFERENCES ordine (idOrdine) ON DELETE CASCADE,
FOREIGN KEY (prodotto_fk) REFERENCES prodotto (idProdotto) ON DELETE CASCADE
);

DROP TABLE IF EXISTS prodotto_taglia;
CREATE TABLE prodotto_taglia (
taglia_fk smallint unsigned NOT NULL,
prodotto_fk smallint unsigned NOT NULL,
PRIMARY KEY (taglia_fk, prodotto_fk),
FOREIGN KEY (taglia_fk) REFERENCES taglia (idTaglia) ON DELETE CASCADE,
FOREIGN KEY (prodotto_fk) REFERENCES prodotto (idProdotto) ON DELETE CASCADE
);

INSERT INTO utente (nome, cognome, email, password, admin) VALUES
("Pietro", "Battistoni", "pietrobattistoni@gmail.com", "1b3a759ebc464bbeb5bc609ba1fc99f1edb78e107103ef4747db8d7445bb2fa419bc19acca1a56de8ac4b3875e6739196823c19fbe3448e0f16321e42d133a3a", false),
("Giuseppe", "Solimene", "giuseppesol@gmail.com", "a1a1d0c3a28515fcf869a86f9209579d01b92d1013f7bf5e52d8c60da31719392cd7542bc6308ffa96d15e74691a27b32f4218f787e11f1b4d8263320fce03a9", true),		-- Ciaociao1
("Mario", "Rossi", "mariorossi@gmail.com", "pollo342", false);

INSERT INTO ordine (totale, dataOrdine, utente_fk) VALUES
(42.50, '2021-04-03', 3), (23.50, '2021-04-12', 3),
(12.50, '2021-06-03', 1);

INSERT INTO datiAnagrafici VALUES
("Signore", "Fisciano", "Via Roma", "86334519757", "30", "84084", "RSSMRA80A01F912G", 3),
("Signore", "Montoro", "Via Garibaldi", "75395470943", "40", "83026", "PBBPTR80A01F912G", 1);

INSERT INTO categoria (nomeCategoria, descrizioneCategoria, immagine) VALUES
("Collo", "Problemi al collo dopo qualche incidente? Scegli tra la nostra varietà di collari cervicali e stabilizzatori sterno-dorsali.","collo.jpg"),	#Categoria 1

("Tronco", "Dolori alla schiena che non ti permettono di muoverti come vorresti? Ti consigliamo i nostri busti ortopedici per ogni esigenza o 
i nostri iperestensori e crocere in seguito a fratture traumatiche.", "tronco.jpg"),	#Categoria 2

("Spalla", "Acquista ortesi e tutori ortopedici indicati per fratture, lussazioni e lesioni alla spalla:
 un ampio catalogo di supporti reggibraccio, aste di appoggio per polso e mano, supporti palmari e fasce 
 di stabilizzazione, bendaggi clavicolari, tutori per abduzione spalla e immobilizzatori di spalla.", "spalla.jpg"),	#Categoria 3
 
("Gomito/Omero","Scegli dal nostro vasto assortimento di ortesi per il gomito e omero tra: 
cinturini in neoprene, gomitiere, epicon bracciale e tutori articolati.", "omero.jpg"),	#Categoria 4

("Avambraccio/Polso", "Acquista ortesi e tutori ortopedici per avambraccio e polso come reggibraccio 
(anche con immobilizzatore), tutori articolati e polsiere.", "avambraccio.jpg"),	#Categoria 5

("Mano", "Un'ampia selezione di tutori e ortesi per mani e dita: in questa sezione trovi tutto ciò
 che riguarda l'immobilizzazione degli arti superiori tra cui ferule digitali, immobilizzatori per dita 
 della mano (anche digitali) e tutori stax.", "mano.jpg"),	#Categoria 6
 
("Anca/Coscia", "Hai bisogno di ortesi per anca e coscia? Ecco un vasto catalogo di articoli ortopedici come supporti per coscia, cosciere in elastico, 
supporti dinamici per trattamenti conservativi, prese e aste per favorire la riabilitazione dopo interventi di endoprotesi.", "anca.jpg"),	#Categoria 7

("Ginocchio", "I tutori per il ginocchio sono utilizzati nel post-operatorio o nello sport per non sottoporre a stress i legamenti, 
con effetti benefici abbastanza rapidi. Le ginocchiere sono dei tutori adatti anche per le lesioni, traumi e rottura del menisco. 
Le fasce elastiche sono indicate per stabilizzare la rotula. Un'ampia gamma di ortesi per ginocchio ideali per favorire la fase di 
riabilitazione in seguito a lesioni: scegli tra i nostri modelli di ginocchiere, 
supporti rotulei e protezioni, cinturini sottorotulei e immobilizzatori per ginocchio.", "ginocchio.jpg"),	#Categoria 8

("Gamba/Caviglia", "Acquista ortesi e tutori per gamba e caviglia con imbottitura per garantire sempre un elevato comfort e stabilizzazione dei legamenti.
 Scegli tra un'ampia selezione di cavigliere in neoprene ed elastiche, fisio tavolette e tutori a stivaletto. 
 Ampia gamma di tutori per la gamba consigliati per quei pazienti che hanno subito degli interventi e quindi è necessario mantenere la gamba 
 immobile e stabilizzata nell'intero periodo post operatorio. Sono consigliate anche nel caso di distorsioni, fratture o rotture dei legamenti.", "caviglia.jpg"),	#Categoria 9

("Piede", "L'ortesi plantare è un dispositivo in silicone che viene inserito all'interno della calzatura allo scopo di modellare la funzione del piede.
 Su Ro+Ten trovi un'ampia gamma di ortesi per piede e accessori quali cerotti protettivi, supporti in silicone e tubolari, divaricatori notturni 
 e talloniere per piede. I tutori per il piede sono di vari tipi: plantari, tallonette, correttori e protettori per l'alluce valgo o per un dito fratturato. 
 Scegli il modello più adatto alle tue esigenze!", "piede.jpg"),		#Categoria 10

("Trazioni/Varie", "Varietà di accessori per la riabiltazione generale e rieducazione post-operatoria come: 
set per la trazione cervicale, bande elastiche in lattice e allenatori per la mobilizzazione passiva", "varie.jpg");		#Categoria 11

INSERT INTO prodotto (quantitaProdotto, scontoProdotto, nomeProdotto, descrizioneBreve, descrizioneDettagliata, indicazioniUtilizzo, prezzoProdotto, immagine, categoria_fk) VALUES
(30, 20, "Polfit 19",
"Polsiera corta apribile in tessuto traspirante con stecca rigida palmare modellabile. Ideale per immobilizzare il polso e
 ridurre il dolore in caso di tendinite, distorsione, frattura e artrite. Versione destra.",
 "La polsiera corta POLFIT19 è un tutore progettato per il trattamento di tendiniti, distorsioni,
 fratture e artrite del polso. Questo tutore, dal design anatomico,
 è realizzato in tessuto 3D traspirante che assicura comodità, leggerezza e una buona tollerabilità.
 Il sostegno del polso e della mano è garantito dalla stecca rigida palmare in alluminio preformata e modellabile
 (rimovibile) e le stecche di rinforzo dorsali in plastica, le quali offrono un'immobilizzazione sicura che permette
 di alleviare il dolore senza però limitare il movimento delle dita e compromettere lo svolgimento delle attività quotidiane.
 La chiusura con fibbie e le cinghie a velcro consentono di chiudere e indossare facilmente la polsiera. Versione destra.",
 "Distorsioni del polso,
  Fratture composte dell'estremità del radio e dell'ulna,
  Tendiniti del polso,
  Artrosi radio-carpica,
  Artrite reumatoide,
  Postumi delle fratture di polso o dopo rimozione precoce del gesso",
  25.33, "polfit19.jpg", 5),
  
(20, 10, "Cervilight", 
  "Collare cervicale in gommapiuma rinforzato. Immobilizza e sostiene il collo alleviando il dolore, è facile da indossare e confortevole.",
  "Il supporto cervicale Cervilight è utile a immobilizzare il tratto cervicale in caso di traumi, distorsioni, artrosi e torcicollo.
  Il design sagomato e la struttura in gommapiuma semirigida a densità calibrata rende il collare leggero e gli consente di adattarsi 
  perfettamente al collo e di alleviare i dolori articolari e le tensioni muscolari. 
  La chiusura posteriore con cinturino a velcro permette di indossare e regolare facilmente il tutore garantendo una vestibilità sicura e personalizzata.
  In questo modo la normale respirazione e la circolazione sanguigna non sono ostacolate e il supporto non reca alcun fastidio. 
  Il collare è dotato di un rivestimento in maglina tubolare di cotone elasticizzato e un rinforzo esterno con fascia in vilpelle atossica,
  è radiotrasparente ed è completamente lavabile.",
  " Distorsioni della colonna cervicale lievi (colpo di frusta),
	Torcicollo,
	Crisi vertiginose di origine cervicale,
	Artrosi cervicale",
    21.09, "cervilight.jpg", 1),
    
(15, 50, "Linear70",
    "Busto lombare in tessuto elastico millerighe e chiusura in velcro per lievi traumi lombosacrali alla 
    colonna e patologie posturali, contratture paravertebrali e lombalgie.",
    "Corsetto lombare elastico basso per trattare patologie posturali, muscolari e degenerative che interessano la parte lombare e sacrale della colonna,
    come lombalgie, traumi alla colonna in forma lieve e contratture muscolari paravertebrali. Questo bustino ortopedico lombare offre inoltre grande
    supporto alla zona dorso-lombare del rachide massimizzando i suoi effetti positivi sul paziente.
    Il busto lombare Linear70 è realizzato in cotone ed elastomero millerighe che gli permette di generare una compressione stabile e uniforme,
    ed è dotato di rinforzo lineare sulla parte posteriore in modo da garantire la corretta distribuzione delle spinte lombari.
    I materiali di realizzazione del busto gli conferiscono poi grande vestibilità e traspirabilità, e la chiusura anteriore in velcro
    permette al paziente di indossarlo e sistemarlo con grande facilità. A seconda delle proprie necessità, questo corsetto lombare può
    essere personalizzato grazie alle 4 guide posteriori in cui è possibile inserire altrettante stecche automodellanti già fornite in dotazione
    o stecche sostitutive di diverso tipo (opzionali: pelota lombare PR1-1078/P, pelota lombare termoformabile PR1-T1000 
    e stecca da 20 cm da rinforzo addizionale 9ST012).",
    "Lombalgie,
    Contratture muscolari paravertebrali,
    Traumi lievi della colonna lombo-sacrale",
    38.65, "linear70.jpg", 2),
    
(17, null, "Acb",
    "Stabilizza la spalla ed il braccio nei casi di lussazione e sublussazione dell'articolazione acromion-claveare",
    "È un dispositivo medico, confortevole e leggero, che assicura un’ottima immobilizzazione dell’articolazione acromion-claveare.
    Il tessuto in misto cotone, traspirante e resistente, consente di mantenere l’arto nella corretta posizione per tutto il periodo 
    della convalescenza, col massimo comfort. La struttura ridotta nelle dimensioni e l’imbottitura a livello delle parti di sostegno
    più sensibili, migliorano notevolmente la sopportabilità. Di facile applicazione, raggiunge la sua posizione funzionale in pochi secondi.",
    "Stabilizza la spalla ed il braccio nei casi di lussazione e sublussazione dell'articolazione acromion-claveare.",
    63.21, "acb.jpg", 3),
    
(22, null, "Epifit 32",
    "Le fasce per epicondilite sono indicate non solo per combattere il dolore ma anche per prevenire o evitare di ricadere in situazioni
    dolorose per il gomito e l’avambraccio. Infatti, queste fasce sono utili per evitare l’insorgere di queste patologie, soprattutto nei
    soggetti predisposti che che fanno lavori o praticano sport a rischio.",
    "È un dispositivo medico, confortevole e leggero, che assicura un’ottima compressione a livello dell’articolazione del gomito.
    L’applicazione è semplice ed immediata, la chiusura a velcro rende veloce il fissaggio, la fibbia in nylon permette di dosare la
    trazione controllando la compressione sotto l’epicondilo. La struttura in tessutoAirX, eccezionalmente traspirante, garantisce comfort
    e un’ottima efficacia anche nell’attività sportiva.",
    "Lievi epicondiliti ed epitrocleiti,
    Contratture muscolari,
    Tendinopatie,
    Post-trauma,
    Artrosinoviti",
    28.21, "epifit32.jpg", 4),
    
(32, null, "Brace-up",
    "Il reggibraccio Brace up è realizzato con un tessuto leggero e confortevole. Ed è indicato per sostenere il braccio del paziente
    nel caso di ingessature, mantenendo l'arto a riposo.",
    "Il reggibraccio Brace Up è fondamentale per mantenere a riposo il braccio nel caso di fasciature o gessature post infortuni o interventi.
    La cinghia del reggibraccio è stata realizzata in nylon e la regolazione al braccio avviene tramite delle fibbie. Per impedire sfregamenti
    e irritazioni, la parte attorno al collo è imbottita con un cuscinetto per il massimo comfort dell'utilizzatore.",
    "Indicato per arti ingessati,
	 Post interventi,
	 Traumi distorsivi",
    17.33, "braceup.jpg", 5),
    
(10, null, "Daumfix",
    "Ortesi per il pollice destinata a immobilizzare e alleviare i dolori al dito in presenza di tendiniti e distorsioni senza limitare
    le normali attività giornaliere. La leggerezza del materiale, il guantino di protezione e il colore chiaro del tutore lo rendono
    confortevole e allo stesso tempo poco vistoso.",
    "L'ortesi per il pollice Daumfix ha lo scopo di proteggere, alleviare il dolore e tenere a riposo il dito senza compromettere in
    maniera eccessiva le funzionalità della mano. La struttura è realizzata in polipropilene levigato e burattato con un cinturino in
    velcro elastico che permette di assicurare il tutore al polso e regolare la chiusura in base alle proprie esigenze. La conformazione
    anatomica dell'ortesi è pensata per garantire il massimo comfort durante l'utilizzo. Le dimesioni ridotte e il colore chiaro lo rendono
    confortevole e quasi invisibile. Prima di applicare l'ortesi, è necessario indossare il guantino in tessuto di cotone elasticizzato (lycra) presente nella confezione.",
    "Rizartrosi,
	Tendiniti del pollice,
	Tendinopatia di De Quervain,
	Distorsione metacarpo-falangea,
	Lesione di Steiner,
	Postumi di frattura di Bennet,
	Postumi di artrodesi trapezio metacarpale e della chirurgia del pollice",
    33.95, "daumfix.jpg", 6),
    
(14, null, "Kafo",
    "Prolungamento per gamba in alluminio con supporto plastico a livello dell'articolazione della caviglia per tutore anca 'Hipo'.
    Migliora il comfort del paziente e permette di ottenere il pieno controllo dei movimenti di flessione, estensione, abduzione e intra-extra rotazione dell'anca.",
    "Il prolungamento per gamba 'Kafo' è un supporto aggiuntivo per i tutori d'anca 'Hipo'. La componente è progettata per migliorare il comfort dei pazienti
    e garantire il perfetto controllo della flesso-estensione, dell'abduzione e della intra/extra-rotazione dell'anca in modo da mantenere l'arto nella posizione
    naturale e ridurre il rischio di lussazioni. Il dispositivo è caratterizzato da una struttura monolaterale in alluminio e un supporto in materiale plastico
    a livello dell'articolazione della caviglia che rendono il tutore particolarmente leggero e diminuisce la possibilità di sviluppare piaghe da decubito,
    caratteristiche fondamentali soprattutto per i pazienti anziani. Per facilitare l'applicazione, il tutore è costituito da due sezioni separabili.",
    "Kafo è il dispositivo aggiunto che assicura all'ortesi d'anca il controllo dei minimi movimenti di rotazione, necessari a mantenere la posizione naturale dell'articolazione",
    237.36, "kafo.jpg", 7),
    
(30, null, "Genufit 60",
    "Ginocchiera tubolare corta in tessuto traspirante ed elasticizzato a compressione con inserto popliteo. Aiuta a sostenere e proteggere
    il ginocchio in caso di contusioni, distorsione dei legamenti e tendinite. Disponibile in diverse taglie.",
    "Il tutore elastico a compressione GenuFIT60 è una ginocchiera corta tubolare indicata per dare sostegno e stabilità all'articolazione del
    ginocchio e alleviare il dolore in presenza di contusioni, tendiniti e distorsioni dei legamenti. Questo tutore è realizzato in tessuto AirX
    altamente traspirante la cui azione compressiva stimola la circolazione sanguigna e riscalda la zona interessata riducendo così i tempi di guarigione.
    La ginocchiera è dotata di inserto popliteo in Soft-X® per offrire maggior comfort durante il movimento di flessione del ginocchio. Il lavaggio va
    effettuato a mano in acqua tiepida con sapone neutro.",
    "Contusioni,
	Tendinite,
	Lievi stati artrosici,
	Distorsioni,
	Strappi muscolari",
    32.17, "genufit60.jpg", 8),
    
(5, null, "Afo",
    "Doccia ortopedica per adulto indicata per mantenere l'arto nella posizione corretta in caso di cadute flaccide del piede ed equinismi spastici
    di media entità. La struttura del tutore è comoda e resistente.",
    "Il tutore ortopedico è realizzato in polipropilene, un materiale resistente e allo stesso tempo modificabile a caldo.
    La doccia è munita di un morbido pannello con una chiusura a velcro all'altezza del polpaccio in modo da proteggere la tibia
    e permettere di svolgere la propria funzione in maniera comoda e sicura.",
    "Cadute flaccide del piede,
     Equinismi spastici di lieve e media entità",
    69.50, "afo.jpg", 9),
    
(22, null, "Talusoft 04",
    "Grazie ad una piccola area a nido d'ape creata all'interno della tallonetta, questi apparecchi
    consentono di alleviare la pressione e il forte dolore sullo sprone.",
    "Il modello Talusoft 04 delle tallonette sono realizzate in materiale viscoelastico, un materiale che assicura alte prestazioni.
    Si caratterizza per una piccola area a nido d'ape creata all'interno della tallonetta, che permette di alleviare la pressione sullo sprone.
    La parte a contatto con il piede, è realizzata con un morbido tessuto scamosciato e un design anatomico ad alta resistenza per u comfort perfetto",
    "Sproni calcaneari,
	Talloniti e talalgie anteriori,
	Morbo di Haglund e di Sever,
	Borsiti retrocalcaneari,
	Prevenzione delle talalgie nella pratica sportiva",
    27.65, "talusoft04.jpg", 10),
    
(18, null, "Cervitrac",
    "Viene applicata una 'fascia tirante' tra collo e mento, collegata ad una sacca piena d'acqua (contrappeso) tramite una carrucola,
    in modo da applicare una certa trazione sul collo. Il peso potrà essere regolato in base alla quantità d'acqua versata nella sacca",
    "Con l’avanzare dell’età le vertebre cervicali si schiacciano a causa della gravità e questo provoca l’erosione delle cartilagini
    che le separano e un doloroso circolo doloroso che affligge tutta la zona che parte dalla nuca fino alla schiena.
    La trazione cervicale cerca di bloccare questo processo degenerativo tirando verso l’alto la testa in modo meccanico ed indolore.
    Per eseguire la terapia la persona deve indossare una apposita imbracatura che sostiene la testa a partire dal mento e viene fissata
    ad una carrucola che esercita un peso contrario.",
    "Artrosi cervicale,
	Rettilineizzazione della fisiologica lordosi cervicale,
	Discopatie cervicali,
	Cervicobrachialgia,
	Riduzione d'ampiezza degli spazi intervertebrali",
    59.74, "cervitrac.jpg", 11);


INSERT INTO taglia (tipo, numero) VALUES
("Universale", null),
("S", "13/16"), ("M", "16/18"), ("L", "18/20"), ("XL", "20/23"),
("XS", "50/60"), ("S", "60/75"), ("M", "75/90"), ("L", "90/105"), ("XL", "105/120"), ("XXL", "120/135");

INSERT INTO ordine_prodotto (ordine_fk, prodotto_fk, taglia_fk, quantita) VALUES
(1, 1, 2, 2), (1, 3, 8, 4);

INSERT INTO prodotto_taglia (taglia_fk, prodotto_fk) VALUES
(2,1), (3,1), (4,1), (5,1),
(1,2),
(6,3),(7,3),(8,3),(9,3),(10,3),(11,3);