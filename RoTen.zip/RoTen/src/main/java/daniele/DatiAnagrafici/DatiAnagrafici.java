package daniele.DatiAnagrafici;

import daniele.Utente.Utente;

public class DatiAnagrafici {
    public DatiAnagrafici() {
        super();
    }

    public String getTitoloSociale() {
        return titoloSociale;
    }

    public void setTitoloSociale(String titoloSociale) {
        this.titoloSociale = titoloSociale;
    }

    public String getCitta() {
        return citta;
    }

    public void setCitta(String citta) {
        this.citta = citta;
    }

    public String getVia() {
        return via;
    }

    public void setVia(String via) {
        this.via = via;
    }

    public String getPartitaIva() {
        return partitaIva;
    }

    public void setPartitaIva(String partitaIva) {
        this.partitaIva = partitaIva;
    }

    public String getNumeroCivico() {
        return numeroCivico;
    }

    public void setNumeroCivico(String numeroCivico) {
        this.numeroCivico = numeroCivico;
    }

    public String getCap() {
        return cap;
    }

    public void setCap(String cap) {
        this.cap = cap;
    }

    public String getCodiceFiscale() {
        return codiceFiscale;
    }

    public void setCodiceFiscale(String codiceFiscale) {
        this.codiceFiscale = codiceFiscale;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    private String titoloSociale, citta, via, partitaIva, numeroCivico, cap, codiceFiscale;
    private Utente utente;
}
