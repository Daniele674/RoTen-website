package daniele.Categoria;

import daniele.Components.Paginator;
import daniele.Prodotto.ProdottoExtractor;
import daniele.utility.QueryBuilder;
import daniele.utility.SqlDao;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SqlCategoriaDao extends SqlDao implements CategoriaDao<SQLException>{

    public SqlCategoriaDao(DataSource source) {
        super(source);
    }

    public List<Categoria> prelevaCategorie(Paginator paginator) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("categoria", "cat");
            String query = queryBuilder.select().limit(true).generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ps.setInt(1, paginator.getOffset());
                ps.setInt(2, paginator.getLimit());
                ResultSet set = ps.executeQuery();
                CategoriaExtractor categoriaExtractor = new CategoriaExtractor();
                List<Categoria> categorie = new ArrayList<>();
                while(set.next()){
                    categorie.add(categoriaExtractor.extract(set));
                }
                return categorie;
            }
        }
    }

    public List<Categoria> prelevaCategorieSolo() throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("categoria", "cat");
            String query = queryBuilder.select().generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                CategoriaExtractor categoriaExtractor = new CategoriaExtractor();
                List<Categoria> categorie = new ArrayList<>();
                while(set.next()){
                    categorie.add(categoriaExtractor.extract(set));
                }
                return categorie;
            }
        }
    }

    public boolean creaCategoria(Categoria categoria) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("categoria", "cat");
            queryBuilder.insert("nomeCategoria", "descrizioneCategoria", "immagine");
            try(PreparedStatement ps = conn.prepareStatement(queryBuilder.generateQuery())){
                ps.setString(1, categoria.getNomeCategoria());
                ps.setString(2, categoria.getDescrizioneCategoria());
                ps.setString(3, categoria.getImmagine());
                int rows = ps.executeUpdate();
                return rows == 1;
            }
        }
    }

    public boolean aggiornaCategoria(Categoria categoria) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("categoria", "cat");
            queryBuilder.update("nomeCategoria", "descrizioneCategoria").where("idCategoria=?");
            try(PreparedStatement ps = conn.prepareStatement(queryBuilder.generateQuery())){
                ps.setString(1, categoria.getNomeCategoria());
                ps.setString(2, categoria.getDescrizioneCategoria());
                ps.setInt(3, categoria.getIdCategoria());
                int rows = ps.executeUpdate();
                return rows == 1;
            }
        }
    }

    @Override
    public int countAll() throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("categoria", "cat");
            String query = queryBuilder.count("totaleCategorie").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                int size = 0;
                if(set.next()){
                    size = set.getInt("totaleCategorie");
                }
                return size;
            }
        }
    }

    public Optional<Categoria> prelevaCategoriaConProdotti(int idCategoria) throws SQLException {       //prelevo una speficifica categoria con tutti i suoi prodotti annessi
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("categoria", "cat");
            queryBuilder.select().innerJoin("prodotto", "pro").on("cat.idCategoria = pro.categoria_fk").where("cat.idCategoria=?");
            try(PreparedStatement ps = conn.prepareStatement(queryBuilder.generateQuery())){
                ps.setInt(1, idCategoria);
                ResultSet set = ps.executeQuery();
                CategoriaExtractor categoriaExtractor = new CategoriaExtractor();
                Categoria categoria = null;
                if(set.next()){         //prendo la prima riga del result set
                    categoria = categoriaExtractor.extract(set);    //estraggo la categoria solo dalla prima riga per non averla ripetuta per tutti i prodotti
                    categoria.setProdotti(new ArrayList<>());       //creo un ArrayList di prodotti nella categoria
                    ProdottoExtractor prodottoExtractor = new ProdottoExtractor();      //estraggo il prodotto solo della prima riga
                    categoria.getProdotti().add(prodottoExtractor.extract(set));        //lo aggiungo all'ArrayList
                    while(set.next()){      //vado ad iterare sul resto delle righe del ResultSet senza andare a prelevare nuovamente la categoria
                        categoria.getProdotti().add(prodottoExtractor.extract(set));        //prendo tutti i restanti prodotti e li inserisco nell'ArrayList
                    }
                }
                return Optional.ofNullable(categoria);
            }
        }
    }
}
