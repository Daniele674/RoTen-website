package daniele.Categoria;

import daniele.http.RequestValidator;

import javax.servlet.http.HttpServletRequest;
import java.util.regex.Pattern;

final class CategoriaValidator {

    static RequestValidator validateForm(HttpServletRequest request, boolean update){
        RequestValidator validator = new RequestValidator(request);
        validator.assertMatch("nomeCategoria", Pattern.compile("^[\\w\\s]{4,20}$"), "Il nome deve avere lunghezza tra 4 e 20 caratteri");
        validator.assertMatch("descrizioneCategoria", Pattern.compile("^[À-ú\\w\\s?,.;:'()-]+$"), "La descrizione non è valida");
        if(update){
            validator.assertInt("idCategoria", "Id deve essere un numero intero");
        }
        return validator;
    }
}
