package daniele.Categoria;

import daniele.http.FormMapper;

import javax.servlet.http.HttpServletRequest;

public class CategoriaFormMapper implements FormMapper<Categoria> {

    public Categoria map(HttpServletRequest request, boolean update){
        Categoria categoria = new Categoria();
        if(update){
            categoria.setIdCategoria(Integer.parseInt(request.getParameter("idCategoria")));
        }
        categoria.setNomeCategoria(request.getParameter("nomeCategoria"));
        categoria.setDescrizioneCategoria(request.getParameter("descrizioneCategoria"));
        return categoria;
    }
}
