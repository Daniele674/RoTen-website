package daniele.Categoria;

import daniele.Components.Paginator;

import java.util.List;
import java.util.Optional;

public interface CategoriaDao <E extends Exception> {
    List<Categoria> prelevaCategorie(Paginator paginator) throws E;     //In lettura restituisce l'entità

    List<Categoria> prelevaCategorieSolo() throws E;

    boolean creaCategoria(Categoria categoria) throws E;          //In scrittura restituisce l'informazione sul successo

    boolean aggiornaCategoria(Categoria categoria) throws E;

    int countAll() throws E;

    Optional<Categoria> prelevaCategoriaConProdotti(int idCategoria) throws E;
}
