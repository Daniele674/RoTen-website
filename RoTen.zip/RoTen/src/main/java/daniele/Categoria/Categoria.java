package daniele.Categoria;

import daniele.Prodotto.Prodotto;
import daniele.http.JsonSerializable;
import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.List;

public class Categoria implements JsonSerializable {

    public Categoria(){super();}

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNomeCategoria() {
        return nomeCategoria;
    }

    public void setNomeCategoria(String nomeCategoria) {
        this.nomeCategoria = nomeCategoria;
    }

    public String getDescrizioneCategoria() {
        return descrizioneCategoria;
    }

    public void setDescrizioneCategoria(String descrizioneCategoria) {
        this.descrizioneCategoria = descrizioneCategoria;
    }

    public List<Prodotto> getProdotti() {
        return prodotti;
    }

    public void setProdotti(List<Prodotto> prodotti) {
        this.prodotti = prodotti;
    }

    public String getImmagine() {
        return immagine;
    }

    public void setImmagine(String immagine) {
        this.immagine = immagine;
    }

    public void addProdotto(Prodotto prodotto){
        prodotti.add(prodotto);
    }

    public int countProdotti(){
        return prodotti.size();
    }

    public boolean hasProdotti(){
        return prodotti.isEmpty();
    }

    @Override
    public JSONObject toJson() throws JSONException {
        JSONObject object = new JSONObject();
        object.put("id", idCategoria);
        object.put("label", nomeCategoria);
        return object;
    }

    public void writeImmagine(String uploadPath, Part stream) throws IOException {
        try(InputStream fileStream = stream.getInputStream()){
            File file = new File(uploadPath + immagine);
            Files.copy(fileStream, file.toPath());
        }
    }

    private int idCategoria;
    private String nomeCategoria, descrizioneCategoria;
    private String immagine;
    private List<Prodotto> prodotti;


}
