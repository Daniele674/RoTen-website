package daniele.Categoria;

import daniele.utility.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CategoriaExtractor implements ResultSetExtractor<Categoria> {

    public Categoria extract(ResultSet resultset) throws SQLException {
        Categoria categoria = new Categoria();
        categoria.setIdCategoria(resultset.getInt("cat.idCategoria"));
        categoria.setNomeCategoria(resultset.getString("cat.nomeCategoria"));
        categoria.setDescrizioneCategoria(resultset.getString("cat.descrizioneCategoria"));
        categoria.setImmagine(resultset.getString("cat.immagine"));
        return categoria;
    }
}