package daniele.Categoria;

import daniele.Components.Alert;
import daniele.Components.Paginator;
import daniele.Prodotto.Prodotto;
import daniele.Prodotto.ProdottoSearch;
import daniele.http.CommonValidator;
import daniele.http.Controller;
import daniele.http.InvalidRequestException;
import daniele.search.Condition;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@WebServlet(name = "CategoriaServlet", value = "/categorie/*")
@MultipartConfig

public class CategoriaServlet extends Controller {

    private CategoriaDao<SQLException> categoriaDao;

    public void init() throws ServletException{
        super.init();
        categoriaDao = new SqlCategoriaDao(source);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch(path){
                case "/":       //mostra categorie (admin)
                    authorize(request.getSession(false));
                    validate((CommonValidator.validatePage(request)));
                    int page = parsePage(request);
                    Paginator paginator = new Paginator(page, 10);
                    List<Categoria> categorie = categoriaDao.prelevaCategorie(paginator);
                    int size = categoriaDao.countAll();
                    request.setAttribute("categorie", categorie);
                    request.setAttribute("pages", paginator.getPages(size));
                    request.getRequestDispatcher(view("crm/categorie")).forward(request,response);
                    break;
                case "/show":       //mostra categoria (admin)
                    authorize(request.getSession(false));
                    validate(CommonValidator.validateId(request));
                    int id = Integer.parseInt(request.getParameter("id"));
                    Optional<Categoria> optCategoria = categoriaDao.prelevaCategoriaConProdotti(id);
                    if(optCategoria.isPresent()){
                        request.setAttribute("categoria", optCategoria.get());
                        request.getRequestDispatcher(view("crm/categoria")).forward(request,response);
                    }else{
                        notFound();
                    }
                    break;
                case "/create":     //crea categoria (admin)
                    authorize(request.getSession(false));
                    request.getRequestDispatcher(view("crm/categoria")).forward(request,response);
                    break;
                case "/api":
                    if(isAjax(request)){
                        List<Categoria> cat = categoriaDao.prelevaCategorie(new Paginator(1,50));
                        JSONObject root = new JSONObject();
                        JSONArray arr = new JSONArray();
                        root.put("categorie", arr);
                        cat.forEach(c -> arr.put(c.toJson()));
                        sendJson(response,root);
                        break;
                    }else{
                        notFound();
                    }
                default:
                    notFound();
            }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch(path){
                case "/create":
                    authorize(request.getSession(false));
                    request.setAttribute("back", view("crm/categoria"));
                    validate(CategoriaValidator.validateForm(request, false));
                    Categoria categoria = new CategoriaFormMapper().map(request, false);
                    Part filePart = request.getPart("immagine");
                    String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                    categoria.setImmagine(fileName);
                    if(categoriaDao.creaCategoria(categoria)){
                        categoria.writeImmagine(getUploadPath(), filePart);
                        request.setAttribute("alert", new Alert(List.of("Categoria Creata!"), "successo"));
                        response.setStatus(HttpServletResponse.SC_CREATED);
                        request.getRequestDispatcher(view("crm/categoria")).forward(request,response);
                    }else{
                        internalError();
                    }
                    break;
                case "/update":     //aggiorna categoria
                    request.setCharacterEncoding("UTF-8");
                    authorize(request.getSession(false));        //autorizzare admin
                    request.setAttribute("back", view("crm/categoria"));
                    validate(CategoriaValidator.validateForm(request, true));
                    Categoria updatedCategoria = new CategoriaFormMapper().map(request, true);
                    request.setAttribute("categoria", updatedCategoria);
                    if(categoriaDao.aggiornaCategoria(updatedCategoria)){
                        request.setAttribute("alert", new Alert(List.of("Categoria Aggiornata!"), "successo"));
                        request.getRequestDispatcher(view("crm/categoria")).forward(request,response);
                    }else{
                        internalError();
                    }
                    break;
                default:
                    notAllowed();
            }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }
}
