package daniele.Utente;

import daniele.Components.Alert;
import daniele.Components.Paginator;
import daniele.http.CommonValidator;
import daniele.http.Controller;
import daniele.http.InvalidRequestException;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@WebServlet(name = "UtenteServlet", value = "/accounts/*")
public class UtenteServlet extends Controller {

    private UtenteDao<SQLException> utenteDao;

    public void init() throws ServletException{
        super.init();
        utenteDao = new SqlUtenteDao(source);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            try{
            String path = getPath(request);
            switch (path) {
                case "/":   //lista utenti (admin)
                    authorize(request.getSession());
                    request.setAttribute("back", view("crm/accounts"));
                    validate(CommonValidator.validatePage(request));
                    int page = parsePage(request);
                    Paginator paginator = new Paginator(page, 50);
                    int size = utenteDao.countAll();
                    request.setAttribute("pages", paginator.getPages(size));
                    List<Utente> utenti = utenteDao.prelevaUtenti(paginator);
                    request.setAttribute("utenti", utenti);
                    request.getRequestDispatcher(view("crm/utenti")).forward(request, response);
                    break;
                case "/create":   //crea utente (admin)
                    authorize(request.getSession(false));
                    request.getRequestDispatcher(view("crm/utente")).forward(request, response);
                    break;
                case "/show":       //aggiornamento info utente (admin)
                    authorize(request.getSession(false));
                    validate(CommonValidator.validateId(request));
                    int idUtente = Integer.parseInt(request.getParameter("id"));
                    Optional<Utente> optUtente = utenteDao.prelevaUtente(idUtente);
                    if (optUtente.isPresent()) {
                        request.setAttribute("utente", optUtente.get());
                        request.getRequestDispatcher(view("crm/utente")).forward(request, response);
                    } else {
                        notFound();
                    }
                    break;
                case "/secret":     //login admin (pagina)
                    request.getRequestDispatcher(view("crm/secret")).forward(request, response);
                    break;
                case "/signup":     //registrazione cliente
                    request.getRequestDispatcher(view("site/signup")).forward(request, response);
                    break;
                case "/signin": //login cliente (pagina)
                    request.getRequestDispatcher(view("site/signin")).forward(request, response);
                    break;
                case "/profile":        //mostra profilo (cliente)
                    int profileId = getUtenteSession(request.getSession(false)).getId();
                    Optional<Utente> profileAccount = utenteDao.prelevaUtente(profileId);
                    if (profileAccount.isPresent()) {
                        request.setAttribute("profile", profileAccount.get());
                        request.getRequestDispatcher(view("site/profile")).forward(request, response);
                    } else {
                        notFound();
                    }
                    break;
                case "/logout":     //logout
                    HttpSession session = request.getSession(false);        //False per non creare la sessione dato che esiste già e la vogliamo solo recuperare
                    authenticate(session);      //non usiamo authorize perchè vogliamo riutilizzare questo caso anche per i clienti che non siano admmin
                    UtenteSession utenteSession = (UtenteSession) session.getAttribute("utenteSession");
                    String redirect = utenteSession.isAdmin() ? "../accounts/secret" : "../pages/";        //se admin rimanda in secret, altrimenti in signin
                    session.removeAttribute("utenteSession");       //ridondante
                    session.invalidate();
                    response.sendRedirect(redirect);
                    break;
                default:
                    notFound();
                }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
        String path = getPath(request);
        switch (path) {
            case "/secret":      //login admin
                request.setAttribute("back", view("crm/secret"));
                validate(UtenteValidator.validateSignIn(request));
                Utente tmpUtente = new Utente();
                tmpUtente.setEmail(request.getParameter("email"));
                tmpUtente.setPassword(request.getParameter("password"));
                Optional<Utente> optUtente = utenteDao.trovaUtente(tmpUtente.getEmail(), tmpUtente.getPassword(), true);
                if (optUtente.isPresent()) {          ///controlliamo che l'utente non sia nullo (che esista nel database)
                    UtenteSession utenteSession = new UtenteSession(optUtente.get());       //creiamo un oggetto di sessione che simula l'account
                    request.getSession(true).setAttribute("utenteSession", utenteSession);      //creiamo la sessione e settiamo l'utente
                    response.sendRedirect("../pages/dashboard");      //ridirige alla pagina principale dell'admin
                } else {
                    throw new InvalidRequestException("Credenziali non valide", List.of("Credenziali non valide"), HttpServletResponse.SC_BAD_REQUEST);
                }
                break;
            case "/create":     //crea nuovo cliente
                authorize(request.getSession(false));
                request.setAttribute("back", view("crm/utente"));
                validate(UtenteValidator.validateForm(request, false));
                Utente utente = new UtenteFormMapper().mapCreaUtente(request, false);
                utente.setPassword(request.getParameter("password"));
                if (utenteDao.creaAdmin(utente)) {
                    request.setAttribute("alert", new Alert(List.of("Utente Creato!"), "successo"));
                    response.setStatus(HttpServletResponse.SC_CREATED);
                    request.getRequestDispatcher(view("crm/utente")).forward(request, response);
                } else {
                    internalError();
                }
                break;
            case "/update":         //aggiorna info cliente (admin)
                authorize(request.getSession(false));
                request.setAttribute("back", view("crm/utente"));
                validate(UtenteValidator.validateForm(request, true));
                Utente updatedUtente = new UtenteFormMapper().mapCreaUtente(request,true);
                if(utenteDao.aggiornaUtente(updatedUtente)){
                    request.setAttribute("utente", updatedUtente);
                    request.setAttribute("alert", new Alert(List.of("Utente Aggiornato!"), "successo"));
                    request.getRequestDispatcher(view("crm/utente")).forward(request,response);
                }else{
                    internalError();
                }
                break;
            case "/signup":     //registrazione cliente
                request.setAttribute("back", view("site/signup"));
                validate(UtenteValidator.validateSignUp(request, false));
                Utente cliente = new UtenteFormMapper().map(request,false);
                cliente.setPassword(request.getParameter("password"));
                if(utenteDao.creaUtente(cliente)){
                    response.sendRedirect("../accounts/signin");
                }else{
                    throw new InvalidRequestException("Credenziali non valide", List.of("Credenziali non valide"), HttpServletResponse.SC_BAD_REQUEST);
                }
                break;
            case "/signin":     //login cliente
                request.setAttribute("back", view("site/signin"));
                validate(UtenteValidator.validateSignIn(request));
                Utente tmpCliente = new Utente();
                tmpCliente.setEmail(request.getParameter("email"));
                tmpCliente.setPassword(request.getParameter("password"));
                Optional<Utente> optCliente = utenteDao.trovaUtente(tmpCliente.getEmail(), tmpCliente.getPassword(), false);
                if (optCliente.isPresent()) {
                    UtenteSession utenteSession = new UtenteSession(optCliente.get());
                    request.getSession(true).setAttribute("utenteSession", utenteSession);
                    response.sendRedirect("../pages/");
                } else {
                    throw new InvalidRequestException("Credenziali non valide", List.of("Credenziali non valide"), HttpServletResponse.SC_BAD_REQUEST);
                }
                break;
            default:
                notAllowed();
        }
        }catch(SQLException | NoSuchAlgorithmException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request,response);
        }
    }
}
