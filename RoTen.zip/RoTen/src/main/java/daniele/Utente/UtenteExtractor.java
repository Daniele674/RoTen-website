package daniele.Utente;

import daniele.utility.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UtenteExtractor implements ResultSetExtractor<Utente> {

    public Utente extract(ResultSet resultset) throws SQLException {
        Utente utente = new Utente();
        utente.setIdUtente(resultset.getInt("ute.idUtente"));
        utente.setNome(resultset.getString("ute.nome"));      //usiamo le stringhe perchè non sapremo come metteremo le servlet
        utente.setCognome(resultset.getString("ute.cognome"));
        utente.setEmail(resultset.getString("ute.email"));
        utente.setAdmin(resultset.getBoolean("ute.admin"));
        return utente;
    }
}
