package daniele.Utente;

import daniele.Components.Paginator;
import daniele.utility.QueryBuilder;
import daniele.utility.SqlDao;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SqlUtenteDao extends SqlDao implements UtenteDao<SQLException>{
    public SqlUtenteDao(DataSource source){
        super(source);
    }

    @Override
    public List<Utente> prelevaUtenti(Paginator paginator) throws SQLException {
        try(Connection conn = source.getConnection()){      //try per la chiusura automatica
            QueryBuilder queryBuilder = new QueryBuilder("utente", "ute");      //istanzio un querybuilder
            String query = queryBuilder.select().limit(true).generateQuery();       //creo la query
            try(PreparedStatement ps = conn.prepareStatement(query)){               //passo la query al preparedstatement
                ps.setInt(1, paginator.getOffset());
                ps.setInt(2, paginator.getLimit());
                ResultSet set = ps.executeQuery();      //eseguo la query inserendola nel ResultSet
                UtenteExtractor utenteExtractor = new UtenteExtractor();
                List<Utente> utenti = new ArrayList<>();
                while (set.next()){     //ciclo sul risultato della query
                    utenti.add(utenteExtractor.extract(set));
                }
                return utenti;
            }
        }
    }

    @Override
    public Optional<Utente> prelevaUtente(int idUtente) throws SQLException {      //usiamo OPTIONAL perchè nel caso in cui venisse restituito NULL potremo controllare attraverso i metodi dell'oggetto
        try(Connection conn = source.getConnection()){      //try per la chiusura automatica
            QueryBuilder queryBuilder = new QueryBuilder("utente", "ute");      //istanzio un querybuilder
            String query = queryBuilder.select().where("ute.idUtente=?").generateQuery();  //creo la query
            try(PreparedStatement ps = conn.prepareStatement(query)){               //passo la query al preparedstatement
                ps.setInt(1,idUtente);
                ResultSet set = ps.executeQuery();      //eseguo la query inserendola nel ResultSet
                Utente utente = null;
                if(set.next()){
                    utente = new UtenteExtractor().extract(set);
                }
                return Optional.ofNullable(utente);
            }
        }
    }

    public Optional<Utente> trovaUtente(String email, String password, boolean admin) throws SQLException{
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("utente", "ute");
            String query = queryBuilder.select().where("ute.email=? and ute.password=? and ute.admin=?").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ps.setString(1, email);
                ps.setString(2, password);
                ps.setBoolean(3, admin);
                ResultSet set = ps.executeQuery();
                Utente utente = null;
                if(set.next()){
                    utente = new UtenteExtractor().extract(set);
                }
                return Optional.ofNullable(utente);
            }
        }
    }

    public boolean creaAdmin(Utente utente) throws SQLException {
        try(Connection conn = source.getConnection()){

            QueryBuilder queryBuilder = new QueryBuilder("utente", "ute");
            String query = queryBuilder.insert("nome", "cognome", "email", "password", "admin").generateQuery();

            try(
                    PreparedStatement ps = conn.prepareStatement(query);
            ){
                ps.setString(1, utente.getNome());
                ps.setString(2, utente.getCognome());
                ps.setString(3, utente.getEmail());
                ps.setString(4, utente.getPassword());
                ps.setBoolean(5, utente.isAdmin());
                int rows = ps.executeUpdate();
                return true;
            }
        }
    }

    @Override
    public boolean creaUtente(Utente utente) throws SQLException {
        try(Connection conn = source.getConnection()){
            conn.setAutoCommit(false);

            QueryBuilder queryBuilder = new QueryBuilder("utente", "ute");
            String query = queryBuilder.insert("nome", "cognome", "email", "password", "admin").generateQuery();

            QueryBuilder queryBuilder1 = new QueryBuilder("datiAnagrafici", "dat");
            String query1 = queryBuilder1.insert("titoloSociale", "citta", "via", "partitaIva", "numeroCivico","cap", "codiceFiscale", "utente_fk").generateQuery();

            try(
                    PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
                    PreparedStatement psDa = conn.prepareStatement(query1);
            ){

                ps.setString(1, utente.getNome());
                ps.setString(2, utente.getCognome());
                ps.setString(3, utente.getEmail());
                ps.setString(4, utente.getPassword());
                ps.setBoolean(5, utente.isAdmin());
                int rows = ps.executeUpdate();

                ResultSet setId = ps.getGeneratedKeys();
                setId.next();
                int id = setId.getInt(1);
                utente.setIdUtente(id);

                int total = rows;

                psDa.setString(1, utente.getDatiAnagrafici().getTitoloSociale());
                psDa.setString(2, utente.getDatiAnagrafici().getCitta());
                psDa.setString(3 ,utente.getDatiAnagrafici().getVia());
                psDa.setString(4, utente.getDatiAnagrafici().getPartitaIva());
                psDa.setString(5, utente.getDatiAnagrafici().getNumeroCivico());
                psDa.setString(6, utente.getDatiAnagrafici().getCap());
                psDa.setString(7, utente.getDatiAnagrafici().getCodiceFiscale());
                psDa.setInt(8, utente.getIdUtente());
                total+= psDa.executeUpdate();

                if(total == (rows + 1)){
                    conn.commit();
                    conn.setAutoCommit(true);
                    return true;
                }else{
                    conn.rollback();
                    conn.setAutoCommit(true);
                    return false;
                }
            }
        }
    }

    public int countAll() throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("utente", "ute");
            String query = queryBuilder.count("totaleUtenti").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                int size = 0;
                if(set.next()){
                    size = set.getInt("totaleUtenti");
                }
                return size;
            }
        }
    }

    public int countAllUtentiNormali() throws SQLException{
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("utente", "ute");
            String query = queryBuilder.count("totaleUtenti").where("admin = 0").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                int size = 0;
                if(set.next()){
                    size = set.getInt("totaleUtenti");
                }
                return size;
            }
        }
    }

    @Override
    public boolean aggiornaUtente(Utente utente) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("utente", "ute");
            queryBuilder.update("nome", "cognome", "email", "admin").where("idUtente=?");
            try(PreparedStatement ps = conn.prepareStatement(queryBuilder.generateQuery())){
                ps.setString(1, utente.getNome());
                ps.setString(2, utente.getCognome());
                ps.setString(3, utente.getEmail());
                ps.setBoolean(4, utente.isAdmin());
                ps.setInt(5, utente.getIdUtente());
                int rows = ps.executeUpdate();
                return rows == 1;
            }
        }
    }

    @Override
    public boolean eliminaUtente(int idUtente) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("utente", "ute");
            queryBuilder.delete().where("idCliente=?");
            try(PreparedStatement ps = conn.prepareStatement(queryBuilder.generateQuery())){
                ps.setInt(1, idUtente);
                int rows = ps.executeUpdate();
                return rows == 1;
            }
        }
    }
}
