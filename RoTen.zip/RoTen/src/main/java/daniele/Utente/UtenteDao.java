package daniele.Utente;

import daniele.Components.Paginator;

import java.util.List;
import java.util.Optional;

public interface UtenteDao <E extends Exception> {
    List<Utente> prelevaUtenti(Paginator paginator) throws E;     //In lettura restituisce l'entità

    Optional<Utente> prelevaUtente(int idUtente) throws E;

    boolean creaUtente(Utente utente) throws E;          //In scrittura restituisce l'informazione sul successo

    boolean creaAdmin(Utente utente) throws E;

    int countAll() throws E;

    int countAllUtentiNormali() throws E;

    Optional<Utente> trovaUtente(String email, String password, boolean admin) throws E;

    boolean aggiornaUtente(Utente utente) throws E;

    boolean eliminaUtente(int idUtente) throws E;
}
