package daniele.Utente;

import daniele.http.RequestValidator;

import javax.servlet.http.HttpServletRequest;
import java.util.regex.Pattern;

final class UtenteValidator {

    static RequestValidator validateForm(HttpServletRequest request, boolean update){
        RequestValidator validator = new RequestValidator(request);
        validator.assertMatch("nome", Pattern.compile("^[a-zA-Z,.'-]{3,}$"), "Nome deve avere più di 3 caratteri");
        validator.assertMatch("cognome", Pattern.compile("^[a-zA-Z,.'-]{3,}$"), "Cognome deve avere più di 3 caratteri");
        validator.assertEmail("email", "Mail non corretta");

        if(!update){
            validator.assertMatch("password", Pattern.compile("^(?=.*[0-9])(?=.*[A-Za-z]).{7,}$"), "La password deve contenere almeno 7 caratteri, una lettera ed un numero");
        }

        if(update){
            validator.assertInt("idUtente", "Id deve essere un numero intero");
        }
        return validator;
    }

    static RequestValidator validateSignIn(HttpServletRequest request){
        RequestValidator validator = new RequestValidator(request);
        validator.assertEmail("email", "Mail o Password non corretta");
        validator.assertMatch("password", Pattern.compile("^(?=.*[0-9])(?=.*[A-Za-z]).{7,}$"), "Mail o Password non corretta");
        return validator;
    }

    static RequestValidator validateSignUp(HttpServletRequest request, boolean update){
        RequestValidator validator = new RequestValidator(request);
        validator.assertMatch("nome", Pattern.compile("^[a-zA-Z,.'-]{3,}$"), "Nome deve avere più di 3 caratteri");
        validator.assertMatch("cognome", Pattern.compile("^[a-zA-Z,.'-]{3,}$"), "Cognome deve avere più di 3 caratteri");
        validator.assertEmail("email", "Mail non corretta");
        validator.assertMatch("password", Pattern.compile("^(?=.*[0-9])(?=.*[A-Za-z]).{7,}$"), "La password deve contenere almeno 7 caratteri, una lettera ed un numero");
        validator.assertMatch("citta", Pattern.compile("^[a-zA-Z ]{1,30}$"), "Città deve contenere solo lettere");
        validator.assertMatch("via", Pattern.compile("^[a-zA-Z ]{1,30}$"), "Via deve contenere solo lettere");
        validator.assertMatchNotRequired("partitaIva", Pattern.compile("^(\\d{11}|^$)$"), "Partita Iva deve avere 11 cifre");
        validator.assertInt("numeroCivico", "Numero civico deve contenere solo numeri");
        validator.assertMatch("cap", Pattern.compile("^\\d{5}$"), "Cap deve contenere 5 numeri");
        validator.assertMatch("codiceFiscale", Pattern.compile("^([a-z]{6}[0-9lmnpqrstuv]{2}[abcdehlmprst]{1}[0-9lmnpqrstuv]{2}[a-z]{1}[0-9lmnpqrstuv]{3}[a-z]{1})$", Pattern.CASE_INSENSITIVE), "Codice Fiscale deve avere 13 caratteri");

        if(update){
            validator.assertInt("idUtente", "Id deve essere un numero intero");
        }
        return validator;
    }
}
