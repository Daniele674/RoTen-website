package daniele.Utente;

import daniele.DatiAnagrafici.DatiAnagrafici;
import daniele.http.FormMapper;

import javax.servlet.http.HttpServletRequest;
import java.security.NoSuchAlgorithmException;

public class UtenteFormMapper implements FormMapper<Utente> {

    @Override
    public Utente map(HttpServletRequest request, boolean update) throws NoSuchAlgorithmException {
        Utente utente = new Utente();
        if(update){
            utente.setIdUtente(Integer.parseInt(request.getParameter("idUtente")));
        }
        utente.setNome(request.getParameter("nome"));
        utente.setCognome(request.getParameter("cognome"));
        utente.setEmail(request.getParameter("email"));
        utente.setAdmin(false);
        utente.setDatiAnagrafici(new DatiAnagrafici());
        utente.getDatiAnagrafici().setCitta(request.getParameter("citta"));
        utente.getDatiAnagrafici().setVia(request.getParameter("via"));
        utente.getDatiAnagrafici().setNumeroCivico(request.getParameter("numeroCivico"));
        utente.getDatiAnagrafici().setPartitaIva(request.getParameter("partitaIva"));
        utente.getDatiAnagrafici().setCap(request.getParameter("cap"));
        utente.getDatiAnagrafici().setCodiceFiscale(request.getParameter("codiceFiscale"));
        utente.getDatiAnagrafici().setTitoloSociale(request.getParameter("titoloSociale"));
        return utente;
    }


    public Utente mapCreaUtente(HttpServletRequest request, boolean update) throws NoSuchAlgorithmException {
        Utente utente = new Utente();
        if(update){
            utente.setIdUtente(Integer.parseInt(request.getParameter("idUtente")));
        }
        utente.setNome(request.getParameter("nome"));
        utente.setCognome(request.getParameter("cognome"));
        utente.setEmail(request.getParameter("email"));
        utente.setAdmin(Boolean.parseBoolean(request.getParameter("admin")));
        /*utente.setDatiAnagrafici(new DatiAnagrafici());
        utente.getDatiAnagrafici().setCitta(request.getParameter("citta"));
        utente.getDatiAnagrafici().setVia(request.getParameter("via"));
        utente.getDatiAnagrafici().setNumeroCivico(request.getParameter("numeroCivico"));
        utente.getDatiAnagrafici().setPartitaIva(request.getParameter("partitaIva"));
        utente.getDatiAnagrafici().setCap(request.getParameter("cap"));
        utente.getDatiAnagrafici().setCodiceFiscale(request.getParameter("codiceFiscale"));
        utente.getDatiAnagrafici().setTitoloSociale(request.getParameter("titoloSociale"));*/
        return utente;
    }
}
