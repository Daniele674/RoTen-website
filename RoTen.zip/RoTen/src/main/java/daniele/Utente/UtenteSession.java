package daniele.Utente;

public class UtenteSession {

    private final String nome, cognome;
    private  final int id;
    private final boolean admin;

    public UtenteSession(Utente utente){
        this.nome = utente.getNome();
        this.cognome = utente.getCognome();
        this.id = utente.getIdUtente();
        this.admin = utente.isAdmin();
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public int getId() {
        return id;
    }

    public boolean isAdmin() {
        return admin;
    }

    public String nomeCompleto(){
        return Character.toString(nome.charAt(0)) + '.' + cognome;
    }
}
