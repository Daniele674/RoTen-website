package daniele.Prodotto;

import daniele.Components.Paginator;
import daniele.search.Condition;

import java.util.List;
import java.util.Optional;

public interface ProdottoDao <E extends Exception>{
    Optional<Prodotto> prelevaProdottoConTaglie(int idProdotto) throws E;

    List<Prodotto> prelevaProdotti(Paginator paginator) throws E;

    boolean creaProdotto(Prodotto prodotto) throws E;

    boolean aggiornaProdotto(Prodotto prodotto) throws E;

    int countAll() throws E;

    int sumQuantita() throws E;

    int countOffers() throws E;

    List<Prodotto> search(List<Condition> conditions) throws E;

    boolean eliminaProdotto(int idProdotto) throws E;

    List<Prodotto> prelevaProdottiInOfferta(Paginator paginator) throws E;
}
