package daniele.Prodotto;

import daniele.http.RequestValidator;

import javax.servlet.http.HttpServletRequest;
import java.util.regex.Pattern;

final class ProdottoValidator {

    static RequestValidator validateForm(HttpServletRequest request, boolean update){
        RequestValidator requestValidator = new RequestValidator(request);
        requestValidator.assertMatch("nomeProdotto", Pattern.compile("^[\\w\\s]{5,30}$"), "Nome compreso tra i 5 ed i 30 caratteri");
        requestValidator.assertDouble("prezzoProdotto", "Prezzo deve essere un numero con la virgola");
        requestValidator.assertInt("quantitaProdotto", "Quantità deve essere un numero intero");
        requestValidator.assertInt("scontoProdotto", "Sconto deve essere un numero intero");
        requestValidator.assertMatch("descrizioneBreve", Pattern.compile("^[À-ú\\w\\s?,.;:'()-]{5,500}$"), "Descrizione Breve compresa tra i 5 ed i 500 caratteri");
        requestValidator.assertMatch("descrizioneDettagliata", Pattern.compile("^[À-ú\\w\\s?,.;:'()-]{5,1500}$"), "Descrizione Dettagliata compresa tra i 5 ed i 1500 caratteri");
        requestValidator.assertMatch("indicazioniUtilizzo", Pattern.compile("^[À-ú\\w\\s?,.;:'()-]{5,500}$"), "Indicazioni Utilizzo compresa tra i 5 ed i 500 caratteri");
        if(update){
            requestValidator.assertInt("idProdotto", "Id deve essere un numero intero");
        }
        return requestValidator;
    }
}
