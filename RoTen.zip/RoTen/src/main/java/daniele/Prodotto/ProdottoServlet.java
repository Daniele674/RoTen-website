package daniele.Prodotto;

import daniele.Components.Alert;
import daniele.Components.Paginator;
import daniele.Taglia.SqlTagliaDao;
import daniele.Taglia.Taglia;
import daniele.Taglia.TagliaDao;
import daniele.http.CommonValidator;
import daniele.http.Controller;
import daniele.http.InvalidRequestException;
import daniele.search.Condition;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@WebServlet(name = "ProdottoServlet", value = "/prodotti/*")
@MultipartConfig

public class ProdottoServlet extends Controller {


    private ProdottoDao<SQLException> prodottoDao;

    public void init() throws ServletException{
        super.init();
        prodottoDao = new SqlProdottoDao(source);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String path = getPath(request);
            switch (path) {
                case "/":
                    authorize(request.getSession(false));
                    int intPage = parsePage(request);
                    Paginator paginator = new Paginator(intPage, 6);
                    int size = prodottoDao.countAll();      //numero di tutti i prodotti nel database
                    request.setAttribute("pages", paginator.getPages(size));        //setto il numero di pagine come attributo
                    List<Prodotto> prodotti = prodottoDao.prelevaProdotti(paginator);
                    request.setAttribute("prodotti", prodotti);
                    request.getRequestDispatcher(view("crm/prodotti")).forward(request, response);
                    break;
                case "/show":
                    authorize(request.getSession(false));
                    validate(CommonValidator.validateId(request));
                    int id = Integer.parseInt(request.getParameter("id"));
                    Optional<Prodotto> optionalProdotto = prodottoDao.prelevaProdottoConTaglie(id);
                    if(optionalProdotto.isPresent()){
                        request.setAttribute("prodotto", optionalProdotto.get());
                        request.getRequestDispatcher(view("crm/prodotto")).forward(request, response);
                    }else{
                        notFound();
                    }
                    break;
                case "/catalogue":
                    int pagina = parsePage(request);
                    Paginator paginator2 = new Paginator(pagina, 12);
                    int num_prod = prodottoDao.countAll();
                    request.setAttribute("pages", paginator2.getPages(num_prod));
                    List<Condition> conditions = new ProdottoSearch().buildSearch(request);
                    List<Prodotto> cercaProdotti = conditions.isEmpty() ?
                            prodottoDao.prelevaProdotti(paginator2) :
                            prodottoDao.search(conditions);
                    request.setAttribute("prodotti", cercaProdotti);
                    request.getRequestDispatcher(view("site/catalogue")).forward(request, response);
                    break;
                case "/offerte":
                    int pagina1 = parsePage(request);
                    Paginator paginator3 = new Paginator(pagina1, 9);
                    int num_prod1 = prodottoDao.countOffers();
                    request.setAttribute("pages", paginator3.getPages(num_prod1));
                    List<Condition> conditions1 = new ProdottoSearch().buildSearch(request);
                    List<Prodotto> cercaProdotti1 = conditions1.isEmpty() ?
                            prodottoDao.prelevaProdottiInOfferta(paginator3) :
                            prodottoDao.search(conditions1);
                    request.setAttribute("prodotti", cercaProdotti1);
                    request.getRequestDispatcher(view("site/offerte")).forward(request,response);
                    break;
                case "/create":
                    authorize(request.getSession(false));
                    TagliaDao<SQLException> tagliaDao = new SqlTagliaDao(source);
                    List<Taglia> taglie = tagliaDao.prelevaTaglieSolo();
                    request.setAttribute("taglie", taglie);
                    request.getRequestDispatcher(view("crm/prodotto")).forward(request,response);
                case "/details":
                    request.setCharacterEncoding("UTF-8");
                    validate(CommonValidator.validateId(request));
                    int idProdotto = Integer.parseInt(request.getParameter("id"));
                    Optional<Prodotto> prodotto = prodottoDao.prelevaProdottoConTaglie(idProdotto);
                    if(prodotto.isPresent()){
                        request.setAttribute("prodotto", prodotto.get());
                        request.getRequestDispatcher(view("site/details")).forward(request, response);
                    }else{
                        notFound();
                    }
                    break;

                default:
                    notFound();
            }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch (path) {
                case "/create":
                    authorize(request.getSession(false));        //autorizzare admin
                    request.setAttribute("back", view("crm/prodotto"));
                    validate(ProdottoValidator.validateForm(request, false));
                    Prodotto prodotto = new ProdottoFormMapper().map(request, false);
                    String[] values = request.getParameterValues("taglie");
                    int[] ids = new int[values.length];
                    for(int i = 0; i < values.length; i++){
                        ids[i] = Integer.parseInt(values[i]);
                    }
                    prodotto.setTaglie(new ArrayList<>());
                    for(int id : ids){
                        Taglia taglia = new Taglia();
                        taglia.setIdTaglia(id);
                        prodotto.getTaglie().add(taglia);
                    }
                    Part filePart = request.getPart("immagine");
                    String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                    prodotto.setImmagine(fileName);
                    if(prodottoDao.creaProdotto(prodotto)){
                        prodotto.writeImmagine(getUploadPath(), filePart);
                        request.setAttribute("alert", new Alert(List.of("Prodotto Creato!"), "successo"));
                        response.setStatus(HttpServletResponse.SC_CREATED);
                        request.getRequestDispatcher(view("crm/prodotto")).forward(request,response);
                    }else{
                        internalError();
                    }
                    break;
                case "/update":
                    request.setCharacterEncoding("UTF-8");
                    authorize(request.getSession(false));        //autorizzare admin
                    request.setAttribute("back", view("crm/prodotto"));
                    validate(ProdottoValidator.validateForm(request, true));
                    Prodotto updatedProduct = new ProdottoFormMapper().map(request, true);
                    request.setAttribute("prodotto", updatedProduct);
                    if(prodottoDao.aggiornaProdotto(updatedProduct)){
                        request.setAttribute("alert", new Alert(List.of("Prodotto Aggiornato!"), "successo"));
                        request.getRequestDispatcher(view("crm/prodotto")).forward(request,response);
                    }else{
                        internalError();
                    }
                    break;
            }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){      //Attiva se la authorize fallisce
            log(e.getMessage());
            e.handle(request, response);
        }
    }
}
