package daniele.Prodotto;

import daniele.Categoria.Categoria;
import daniele.http.FormMapper;

import javax.servlet.http.HttpServletRequest;

public class ProdottoFormMapper implements FormMapper<Prodotto> {

    public Prodotto map(HttpServletRequest request, boolean update) {
        Prodotto prodotto = new Prodotto();
        prodotto.setCategoria(new Categoria());
        if(update){
            prodotto.setIdProdotto(Integer.parseInt(request.getParameter("idProdotto")));
        }
        prodotto.setNomeProdotto(request.getParameter("nomeProdotto"));
        prodotto.setPrezzoProdotto(Double.parseDouble(request.getParameter("prezzoProdotto")));
        prodotto.setQuantitaProdotto(Integer.parseInt(request.getParameter("quantitaProdotto")));
        prodotto.setScontoProdotto(Integer.parseInt(request.getParameter("scontoProdotto")));
        prodotto.setDescrizioneBreve(request.getParameter("descrizioneBreve"));
        prodotto.setDescrizioneDettagliata(request.getParameter("descrizioneDettagliata"));
        prodotto.setIndicazioniUtilizzo(request.getParameter("indicazioniUtilizzo"));
        prodotto.getCategoria().setIdCategoria(Integer.parseInt(request.getParameter("categoria")));
        return prodotto;
    }
}
