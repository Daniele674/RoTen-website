package daniele.Prodotto;

import daniele.Categoria.Categoria;
import daniele.Taglia.Taglia;

import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.List;

public class Prodotto {

    public Prodotto() {
        super();
    }

    public String getDescrizioneBreve() {
        return descrizioneBreve;
    }

    public void setDescrizioneBreve(String descrizioneBreve) {
        this.descrizioneBreve = descrizioneBreve;
    }

    public String getDescrizioneDettagliata() {
        return descrizioneDettagliata;
    }

    public void setDescrizioneDettagliata(String descrizioneDettagliata) {
        this.descrizioneDettagliata = descrizioneDettagliata;
    }

    public String getNomeProdotto() {
        return nomeProdotto;
    }

    public void setNomeProdotto(String nomeProdotto) {
        this.nomeProdotto = nomeProdotto;
    }

    public String getIndicazioniUtilizzo() {
        return indicazioniUtilizzo;
    }

    public void setIndicazioniUtilizzo(String indicazioniUtilizzo) {
        this.indicazioniUtilizzo = indicazioniUtilizzo;
    }

    public int getIdProdotto() {
        return idProdotto;
    }

    public void setIdProdotto(int idProdotto) {
        this.idProdotto = idProdotto;
    }

    public int getQuantitaProdotto() {
        return quantitaProdotto;
    }

    public void setQuantitaProdotto(int quantitaProdotto) {
        this.quantitaProdotto = quantitaProdotto;
    }

    public int getScontoProdotto() {
        return scontoProdotto;
    }

    public void setScontoProdotto(int scontoProdotto) {
        this.scontoProdotto = scontoProdotto;
    }

    public double getPrezzoProdotto() {
        return prezzoProdotto;
    }

    public void setPrezzoProdotto(double prezzoProdotto) {
        this.prezzoProdotto = prezzoProdotto;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public List<Taglia> getTaglie() {
        return taglie;
    }

    public void setTaglie(List<Taglia> taglie) {
        this.taglie = taglie;
    }

    public String getImmagine() {
        return immagine;
    }

    public void setImmagine(String immagine) {
        this.immagine = immagine;
    }

    public void writeImmagine(String uploadPath, Part stream) throws IOException {
        try(InputStream fileStream = stream.getInputStream()){
            File file = new File(uploadPath + immagine);
            Files.copy(fileStream, file.toPath());
        }
    }

    private String descrizioneBreve, descrizioneDettagliata, nomeProdotto, indicazioniUtilizzo, immagine;
    private int idProdotto, quantitaProdotto, scontoProdotto;
    private double prezzoProdotto;
    private Categoria categoria;
    private List<Taglia> taglie;
}
