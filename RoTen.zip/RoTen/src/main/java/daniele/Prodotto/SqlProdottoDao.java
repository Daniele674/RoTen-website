package daniele.Prodotto;
import daniele.Categoria.Categoria;
import daniele.Categoria.CategoriaExtractor;
import daniele.Components.Paginator;
import daniele.Taglia.Taglia;
import daniele.Taglia.TagliaExtractor;
import daniele.search.Condition;
import daniele.search.Operator;
import daniele.utility.QueryBuilder;
import daniele.utility.SqlDao;

import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

public class SqlProdottoDao extends SqlDao implements ProdottoDao<SQLException> {

    public SqlProdottoDao(DataSource source) {
        super(source);
    }

    public Optional<Prodotto> prelevaProdottoConTaglie(int idProdotto) throws SQLException {
        try (Connection conn = source.getConnection()) {
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");
            String query = queryBuilder.select().innerJoin("prodotto_taglia", "pt").on("pro.idProdotto = pt.prodotto_fk")
                    .innerJoin("taglia", "tag").on("tag.idTaglia = pt.taglia_fk")
                    .innerJoin("categoria", "cat").on("cat.idCategoria = pro.categoria_fk")
                    .where("pro.idProdotto = ?").generateQuery();
            try (PreparedStatement ps = conn.prepareStatement(query)) {               //passo la query al preparedstatement
                ps.setInt(1, idProdotto);
                ResultSet set = ps.executeQuery();
                ProdottoExtractor prodottoExtractor = new ProdottoExtractor();
                Prodotto prodotto = null;
                if (set.next()) {           //prima riga del result set
                    prodotto = prodottoExtractor.extract(set);
                    prodotto.setTaglie(new ArrayList<>());
                    CategoriaExtractor categoriaExtractor = new CategoriaExtractor();
                    TagliaExtractor tagliaExtractor = new TagliaExtractor();
                    Taglia taglia = tagliaExtractor.extract(set);
                    Categoria categoria = categoriaExtractor.extract(set);
                    prodotto.getTaglie().add(taglia);
                    prodotto.setCategoria(categoria);
                    while(set.next()){
                            taglia = tagliaExtractor.extract(set);
                            prodotto.getTaglie().add(taglia);
                    }
                }
                return Optional.ofNullable(prodotto);
            }
        }
    }

    @Override
    public List<Prodotto> prelevaProdotti(Paginator paginator) throws SQLException {
        try(Connection conn = source.getConnection()){      //try per la chiusura automatica
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");      //istanzio un querybuilder
            String query = queryBuilder.select().limit(true).generateQuery();       //creo la query
            try(PreparedStatement ps = conn.prepareStatement(query)){               //passo la query al preparedstatement
                ps.setInt(1, paginator.getOffset());
                ps.setInt(2, paginator.getLimit());
                ResultSet set = ps.executeQuery();      //eseguo la query inserendola nel ResultSet
                ProdottoExtractor prodottoExtractor = new ProdottoExtractor();
                List<Prodotto> prodotti = new ArrayList<>();
                while (set.next()){     //ciclo sul risultato della query
                    prodotti.add(prodottoExtractor.extract(set));
                }
                return prodotti;
            }
        }
    }

    public List<Prodotto> prelevaProdottiInOfferta(Paginator paginator) throws SQLException {
        try(Connection conn = source.getConnection()){      //try per la chiusura automatica
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");      //istanzio un querybuilder
            String query = queryBuilder.select().where("pro.scontoProdotto IS NOT NULL").limit(true).generateQuery();       //creo la query
            try(PreparedStatement ps = conn.prepareStatement(query)){               //passo la query al preparedstatement
                ps.setInt(1, paginator.getOffset());
                ps.setInt(2, paginator.getLimit());
                ResultSet set = ps.executeQuery();      //eseguo la query inserendola nel ResultSet
                ProdottoExtractor prodottoExtractor = new ProdottoExtractor();
                List<Prodotto> prodotti = new ArrayList<>();
                while (set.next()){     //ciclo sul risultato della query
                    prodotti.add(prodottoExtractor.extract(set));
                }
                return prodotti;
            }
        }
    }

    public boolean creaProdotto(Prodotto prodotto) throws SQLException {
        try(Connection conn = source.getConnection()){
            conn.setAutoCommit(false);
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");
            String query = queryBuilder.insert("quantitaProdotto", "scontoProdotto", "nomeProdotto", "descrizioneBreve", "descrizioneDettagliata", "indicazioniUtilizzo", "prezzoProdotto", "immagine", "categoria_fk").generateQuery();
            QueryBuilder queryBuilder1 = new QueryBuilder("prodotto_taglia", "pt");
            String query1 = queryBuilder1.insert("taglia_fk", "prodotto_fk").generateQuery();

            try(
                PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
                PreparedStatement psAssoc = conn.prepareStatement(query1);
            ){
                ps.setInt(1, prodotto.getQuantitaProdotto());
                ps.setInt(2, prodotto.getScontoProdotto());
                ps.setString(3, prodotto.getNomeProdotto());
                ps.setString(4, prodotto.getDescrizioneBreve());
                ps.setString(5, prodotto.getDescrizioneDettagliata());
                ps.setString(6, prodotto.getIndicazioniUtilizzo());
                ps.setDouble(7, prodotto.getPrezzoProdotto());
                ps.setString(8, prodotto.getImmagine());
                ps.setInt(9, prodotto.getCategoria().getIdCategoria());
                int rows = ps.executeUpdate();
                ResultSet setId = ps.getGeneratedKeys();
                setId.next();
                int id = setId.getInt(1);
                prodotto.setIdProdotto(id);
                int total = rows;
                for(int i = 0; i < prodotto.getTaglie().size(); i++){
                    psAssoc.setInt(1, prodotto.getTaglie().get(i).getIdTaglia());
                    psAssoc.setInt(2, prodotto.getIdProdotto());
                    total += psAssoc.executeUpdate();
                }

                if(total == (rows + prodotto.getTaglie().size())){
                    conn.commit();
                    conn.setAutoCommit(true);
                    return true;
                }else{
                    conn.rollback();
                    conn.setAutoCommit(true);
                    return false;
                }
            }
        }
    }

    public boolean aggiornaProdotto(Prodotto prodotto) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");
            queryBuilder.update("quantitaProdotto", "scontoProdotto", "nomeProdotto", "descrizioneBreve", "descrizioneDettagliata", "indicazioniUtilizzo", "prezzoProdotto", "categoria_fk").where("idProdotto=?");
            try(PreparedStatement ps = conn.prepareStatement(queryBuilder.generateQuery())){
                ps.setInt(1, prodotto.getQuantitaProdotto());
                ps.setInt(2, prodotto.getScontoProdotto());
                ps.setString(3, prodotto.getNomeProdotto());
                ps.setString(4, prodotto.getDescrizioneBreve());
                ps.setString(5, prodotto.getDescrizioneDettagliata());
                ps.setString(6, prodotto.getIndicazioniUtilizzo());
                ps.setDouble(7, prodotto.getPrezzoProdotto());
                ps.setInt(8, prodotto.getCategoria().getIdCategoria());
                ps.setInt(9, prodotto.getIdProdotto());
                int rows = ps.executeUpdate();
                return rows == 1;
            }
        }
    }

    public int countAll() throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");
            String query = queryBuilder.count("totaleProdotti").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                int size = 0;
                if(set.next()){
                    size = set.getInt("totaleProdotti");
                }
                return size;
            }
        }
    }

    public int sumQuantita() throws SQLException{
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");
            String query = queryBuilder.sum("quantitaProdotto").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                int size = 0;
                if(set.next()){
                    size = set.getInt("quantitaProdotto");
                }
                return size;
            }
        }
    }

    public int countOffers() throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");
            String query = queryBuilder.count("totaleOfferte").where("scontoProdotto IS NOT NULL").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                int size = 0;
                if(set.next()){
                    size = set.getInt("totaleOfferte");
                }
                return size;
            }
        }
    }

    public List<Prodotto> search(List<Condition> conditions) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");
            queryBuilder.select()
                    .innerJoin("categoria", "cat").on("pro.categoria_fk = cat.idCategoria");
            if(!conditions.isEmpty()){
                queryBuilder.where().search(conditions);
            }
            String query = queryBuilder.generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                for(int i = 0; i < conditions.size(); i++){
                    if(conditions.get(i).getOperator() == Operator.MATCH){
                        ps.setObject(i+1, "%" + conditions.get(i).getValue() + "%");
                    }else{
                        ps.setObject(i+1, conditions.get(i).getValue());
                    }
                }
                ResultSet set = ps.executeQuery();
                List<Prodotto> prodotti = new ArrayList<>();
                while(set.next()){
                    Prodotto prodotto = new ProdottoExtractor().extract(set);
                    prodotto.setCategoria(new CategoriaExtractor().extract(set));
                    prodotti.add(prodotto);
                }
                return prodotti;
            }
        }
    }



    public boolean eliminaProdotto(int idProdotto) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("prodotto", "pro");
            queryBuilder.delete().where("idProdotto=?");
            try(PreparedStatement ps = conn.prepareStatement(queryBuilder.generateQuery())){
                ps.setInt(1, idProdotto);
                int rows = ps.executeUpdate();
                return rows == 1;
            }
        }
    }
}
