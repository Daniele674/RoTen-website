package daniele.Prodotto;

import daniele.utility.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ProdottoExtractor implements ResultSetExtractor<Prodotto> {

    public Prodotto extract(ResultSet resultset) throws SQLException {
        Prodotto prodotto = new Prodotto();
        prodotto.setIdProdotto(resultset.getInt("pro.idProdotto"));
        prodotto.setNomeProdotto(resultset.getString("pro.nomeProdotto"));
        prodotto.setDescrizioneBreve(resultset.getString("pro.descrizioneBreve"));
        prodotto.setDescrizioneDettagliata(resultset.getString("pro.descrizioneDettagliata"));
        prodotto.setPrezzoProdotto(resultset.getDouble("pro.prezzoProdotto"));
        prodotto.setScontoProdotto(resultset.getInt("pro.scontoProdotto"));
        prodotto.setQuantitaProdotto(resultset.getInt("pro.quantitaProdotto"));
        prodotto.setIndicazioniUtilizzo(resultset.getString("pro.indicazioniUtilizzo"));
        prodotto.setImmagine(resultset.getString("pro.immagine"));

        return prodotto;
    }
}