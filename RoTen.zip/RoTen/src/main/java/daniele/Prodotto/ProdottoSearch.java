package daniele.Prodotto;

import daniele.http.SearchBuilder;
import daniele.search.Condition;
import daniele.search.Operator;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

public class ProdottoSearch implements SearchBuilder {


    public List<Condition> buildSearch(HttpServletRequest request) {
        List<Condition> conditions = new ArrayList<>();
        Enumeration<String> parameterNames = request.getParameterNames();
        while(parameterNames.hasMoreElements()){
            String param = parameterNames.nextElement();
            String value = request.getParameter(param);
            if(value != null && !value.isBlank()){
                switch(param){
                    case "Nome":
                        conditions.add(new Condition("nomeProdotto", Operator.MATCH, value));
                        break;
                    case "idCategoria":
                        conditions.add(new Condition("categoria_fk", Operator.EQ, value));
                        break;
                    case "minPrezzo":
                        conditions.add(new Condition("prezzoProdotto", Operator.GT, value));
                        break;
                    case "maxPrezzo":
                        conditions.add(new Condition("prezzoProdotto", Operator.LT, value));
                        break;
                    default:
                        break;
                }
            }
        }
        return conditions;
    }
}
