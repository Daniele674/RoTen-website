package daniele.http;

import daniele.Utente.UtenteSession;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;

public interface ErrorHandler {

    default void authenticate(HttpSession session) throws InvalidRequestException{      //Controlla se la sessione esiste
        if(session == null || session.getAttribute("utenteSession") == null){       //Vede se la sessione è null o se non è stata settata
            throw new InvalidRequestException("Errore autenticazione", List.of("Non sei autenticato"), HttpServletResponse.SC_UNAUTHORIZED);
        }
    }

    default void authorize(HttpSession session) throws InvalidRequestException{
        authenticate(session);      //Se la sessione non esiste lancia un'eccezione
        UtenteSession utenteSession = (UtenteSession) session.getAttribute("utenteSession");        //Prendo la sessione
        if(!utenteSession.isAdmin()){           //Controllo se è un admin che ha l'autorizzazione ad entrare in questa pagina
            throw new InvalidRequestException("Errore autorizzazione", List.of("Azione non consentita"), HttpServletResponse.SC_FORBIDDEN);
        }
    }

    default void internalError() throws InvalidRequestException{
        List<String> errors = List.of("Un errore imprevisto è accaduto" , "Riprova più tardi");
        throw new InvalidRequestException("Errore interno", errors, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }

    default void notFound() throws InvalidRequestException{
        throw new InvalidRequestException("Errore interno", List.of("Risorsa non trovata"), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }

    default void notAllowed() throws InvalidRequestException{
        throw new InvalidRequestException("Operazione non consentita", List.of("Operazione non permessa"), HttpServletResponse.SC_METHOD_NOT_ALLOWED);
    }
}
