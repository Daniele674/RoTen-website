package daniele.http;

import javax.servlet.http.HttpServletRequest;
import java.security.NoSuchAlgorithmException;

public interface FormMapper <E>{
    public E map(HttpServletRequest request, boolean update) throws NoSuchAlgorithmException;
}
