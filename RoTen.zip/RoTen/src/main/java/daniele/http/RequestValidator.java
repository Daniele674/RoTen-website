package daniele.http;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public class RequestValidator {
    private final List<String> errors;          //Lista degli errori che si accumuleranno
    private final HttpServletRequest request;
    private static final Pattern INT_PATTERN = Pattern.compile("^\\d+$");
    private static final Pattern DOUBLE_PATTERN = Pattern.compile("^(-)?(0|[1-9]\\d+)\\.\\d+$");

    public RequestValidator(HttpServletRequest request){
        this.errors = new ArrayList<>();
        this.request = request;
    }

    public boolean hasErrors(){
        return !errors.isEmpty();
    }

    public List<String> getErrors(){
        return errors;
    }

    private boolean gatherError(boolean condition, String message){     //se la validazione ha trovato un errore aggiunge alla lista di errori e torna false, true altrimenti
        if(condition){
            return true;
        }else{
            errors.add(message);
            return false;
        }
    }

    private boolean required(String value){     //Controlliamo se un campo è obbligatorio
        return value != null && !value.isBlank();
    }

    public boolean assertMatch(String value, Pattern regexp, String msg){       //metodo di base sulle regexp
        String param = request.getParameter(value);
        boolean condition = required(param) && regexp.matcher(param).matches();     //ci assicuriamo prima che il parametro non sia nullo e poi che la stringa faccia match con l'espressione regolare tramite la classe Pattern
        return gatherError(condition, msg);
    }

    public boolean assertMatchNotRequired(String value, Pattern regexp, String msg){
        String param = request.getParameter(value);
        boolean condition = regexp.matcher(param).matches();
        return gatherError(condition, msg);
    }

    public boolean assertInt(String value, String msg){
        return assertMatch(value, INT_PATTERN, msg);
    }

    public boolean assertDouble(String value, String msg){
        return assertMatch(value, DOUBLE_PATTERN, msg);
    }

    public boolean assertEmail(String value, String msg){
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9.!#$%&'*+=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$");
        return assertMatch(value, pattern, msg);
    }

    public boolean assertInts(String values, String msg){   //valida un array per controllare se sono tutti interi
        String[] params = request.getParameterValues(values);
        boolean allInt = Arrays.stream(params).allMatch(param -> INT_PATTERN.matcher(param).matches());
        return gatherError(allInt, msg);
    }

    public boolean assertSize(String first, String second, String msg){     //se due liste hanno la stessa lunghezza
        String[] firstList = request.getParameterValues(first);
        String[] secondList = request.getParameterValues(second);
        return gatherError(firstList.length == secondList.length, msg);
    }

}
