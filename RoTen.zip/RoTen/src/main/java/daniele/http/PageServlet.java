package daniele.http;

import daniele.Categoria.Categoria;
import daniele.Categoria.CategoriaDao;
import daniele.Categoria.SqlCategoriaDao;
import daniele.Components.Paginator;
import daniele.Ordine.OrdineDao;
import daniele.Ordine.SqlOrdineDao;
import daniele.Prodotto.Prodotto;
import daniele.Prodotto.ProdottoDao;
import daniele.Prodotto.SqlProdottoDao;
import daniele.Utente.SqlUtenteDao;
import daniele.Utente.UtenteDao;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "PageServlet", value = "/pages/*")
public class PageServlet extends Controller {

    private CategoriaDao<SQLException> categoriaDao;
    private UtenteDao<SQLException> utenteDao;
    private OrdineDao<SQLException> ordineDao;
    private ProdottoDao<SQLException> prodottoDao;

    public void init() throws ServletException{
        try{
            super.init();
            utenteDao = new SqlUtenteDao(source);
            prodottoDao = new SqlProdottoDao(source);
            ordineDao = new SqlOrdineDao(source);
            categoriaDao = new SqlCategoriaDao(source);
            List<Categoria> categorie = categoriaDao.prelevaCategorieSolo();
            ServletContext context = getServletContext();
            context.setAttribute("categorie", categorie);
        }catch(SQLException ex){
            log(ex.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch(path){
                case "/dashboard":
                    authorize(request.getSession(false));
                    int numUtenti = utenteDao.countAllUtentiNormali();
                    request.setAttribute("numUtenti", numUtenti);
                    int numProdotti = prodottoDao.sumQuantita();
                    request.setAttribute("numProdotti", numProdotti);
                    int totaleOrdini = ordineDao.sumTotaleOrdini();
                    request.setAttribute("totaleOrdini", totaleOrdini);
                    int numOrdini = ordineDao.countAll();
                    request.setAttribute("numOrdini", numOrdini);
                    request.getRequestDispatcher(view("crm/home")).forward(request,response);
                    break;
                case "/":
                    request.getRequestDispatcher(view("site/home")).forward(request,response);
                    break;
                default:
                    notFound();
            }
        }catch(SQLException e){
            log(e.getMessage());
        }catch(InvalidRequestException ex){
            log(ex.getMessage());
            ex.handle(request,response);
        }
    }
}
