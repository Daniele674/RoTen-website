package daniele.Taglia;

import daniele.http.RequestValidator;

import javax.servlet.http.HttpServletRequest;
import java.util.regex.Pattern;

final class TagliaValidator {

    static RequestValidator validateForm(HttpServletRequest request, boolean update){
        RequestValidator validator = new RequestValidator(request);
        //validator.assertMatchNotRequired("numero", Pattern.compile("^[0-9]+[\\/]{1}[0-9]+$|^$"), "Numero deve avere pattern (numero/numero) o essere vuoto se tipo = UNIVERSALE");
        validator.assertMatchNotRequired("numero", Pattern.compile("^([0-9]+[\\/]{1}[0-9]+)*$"), "Numero deve avere pattern (numero/numero) o essere vuoto se tipo = UNIVERSALE");
        validator.assertMatch("tipo", Pattern.compile("^([xs]{2}|[s]{1}|[m]{1}|[l]{1}|[xl]{2}|[xxl]{3}|\\buniversale\\b)$", Pattern.CASE_INSENSITIVE), "Valori accettati per tipo (XS,S,M,L,XL,XXL)");
        if(update){
            validator.assertInt("idTaglia", "Id deve essere un numero intero");
        }
        return validator;
    }
}
