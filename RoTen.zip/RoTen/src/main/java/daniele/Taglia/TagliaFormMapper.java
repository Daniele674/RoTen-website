package daniele.Taglia;

import daniele.http.FormMapper;

import javax.servlet.http.HttpServletRequest;

public class TagliaFormMapper implements FormMapper<Taglia> {
    @Override
    public Taglia map(HttpServletRequest request, boolean update){
        Taglia taglia = new Taglia();
        if(update){
            taglia.setIdTaglia(Integer.parseInt(request.getParameter("idTaglia")));
        }
        taglia.setNumero(request.getParameter("numero"));
        taglia.setTipo(request.getParameter("tipo"));
        return taglia;
    }
}
