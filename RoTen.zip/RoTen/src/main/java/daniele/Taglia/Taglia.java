package daniele.Taglia;

import daniele.Prodotto.Prodotto;

import java.util.List;

public class Taglia {
    public Taglia() {
        super();
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public int getIdTaglia() {
        return idTaglia;
    }

    public void setIdTaglia(int idTaglia) {
        this.idTaglia = idTaglia;
    }

    public List<Prodotto> getProdotti() {
        return prodotti;
    }

    public void setProdotti(List<Prodotto> prodotti) {
        this.prodotti = prodotti;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (!(obj instanceof Taglia)) {
            return false;
        }

        Taglia c = (Taglia) obj;

        return c.numero.equals(this.numero) && c.tipo.equals(this.tipo);
    }

    private String tipo;
    private String numero;
    private int idTaglia;
    private List<Prodotto> prodotti;
}
