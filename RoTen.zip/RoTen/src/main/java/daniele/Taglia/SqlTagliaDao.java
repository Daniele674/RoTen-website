package daniele.Taglia;

import daniele.Categoria.Categoria;
import daniele.Categoria.CategoriaExtractor;
import daniele.Components.Paginator;
import daniele.Prodotto.Prodotto;
import daniele.Prodotto.ProdottoExtractor;
import daniele.utility.QueryBuilder;
import daniele.utility.SqlDao;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SqlTagliaDao extends SqlDao implements TagliaDao<SQLException> {

    public SqlTagliaDao(DataSource source){super(source);}


    public List<Taglia> prelevaTaglie(Paginator paginator) throws SQLException {
        try(Connection conn = source.getConnection()){      //try per la chiusura automatica
            QueryBuilder queryBuilder = new QueryBuilder("taglia", "tag");      //istanzio un querybuilder
            String query = queryBuilder.select().limit(true).generateQuery();       //creo la query
            try(PreparedStatement ps = conn.prepareStatement(query)){               //passo la query al preparedstatement
                ps.setInt(1, paginator.getOffset());
                ps.setInt(2, paginator.getLimit());
                ResultSet set = ps.executeQuery();      //eseguo la query inserendola nel ResultSet
                TagliaExtractor tagliaExtractor = new TagliaExtractor();
                List<Taglia> taglie = new ArrayList<>();
                while (set.next()){     //ciclo sul risultato della query
                    taglie.add(tagliaExtractor.extract(set));
                }
                return taglie;
            }
        }
    }

    public List<Taglia> prelevaTaglieSolo() throws SQLException {
        try(Connection conn = source.getConnection()){      //try per la chiusura automatica
            QueryBuilder queryBuilder = new QueryBuilder("taglia", "tag");      //istanzio un querybuilder
            String query = queryBuilder.select().generateQuery();       //creo la query
            try(PreparedStatement ps = conn.prepareStatement(query)){               //passo la query al preparedstatement
                ResultSet set = ps.executeQuery();      //eseguo la query inserendola nel ResultSet
                TagliaExtractor tagliaExtractor = new TagliaExtractor();
                List<Taglia> taglie = new ArrayList<>();
                while (set.next()){     //ciclo sul risultato della query
                    taglie.add(tagliaExtractor.extract(set));
                }
                return taglie;
            }
        }
    }

    public Optional<Taglia> prelevaTaglia(int idTaglia) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("taglia", "tag");
            String query = queryBuilder.select().where("tag.idTaglia=?").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ps.setInt(1, idTaglia);
                ResultSet set = ps.executeQuery();
                Taglia taglia = null;
                if(set.next()){
                    taglia = new TagliaExtractor().extract(set);
                }
                return Optional.ofNullable(taglia);
            }
        }
    }

    public int countAll() throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("taglia", "tag");
            String query = queryBuilder.count("totaleTaglie").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                int size = 0;
                if(set.next()){
                    size = set.getInt("totaleTaglie");
                }
                return size;
            }
        }
    }

    public boolean creaTaglia(Taglia taglia) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("taglia", "tag");
            queryBuilder.insert("tipo", "numero");
            try(PreparedStatement ps = conn.prepareStatement(queryBuilder.generateQuery())){
                ps.setString(1, taglia.getTipo());
                ps.setString(2, taglia.getNumero());
                int rows = ps.executeUpdate();
                return rows == 1;
            }
        }
    }

    public boolean aggiornaTaglia(Taglia taglia) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("taglia", "tag");
            queryBuilder.update("tipo", "numero").where("idTaglia=?");
            try(PreparedStatement ps = conn.prepareStatement(queryBuilder.generateQuery())){
                ps.setString(1,taglia.getTipo());
                ps.setString(2, taglia.getNumero());
                ps.setInt(3, taglia.getIdTaglia());
                int rows = ps.executeUpdate();
                return rows == 1;
            }
        }
    }
}
