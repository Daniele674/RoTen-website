package daniele.Taglia;

import daniele.Prodotto.Prodotto;
import daniele.utility.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TagliaExtractor implements ResultSetExtractor<Taglia> {

    public Taglia extract(ResultSet resultset) throws SQLException {
        Taglia taglia = new Taglia();
        taglia.setIdTaglia(resultset.getInt("tag.idTaglia"));
        taglia.setNumero(resultset.getString("tag.numero"));
        taglia.setTipo(resultset.getString("tag.tipo"));

        return taglia;
    }
}