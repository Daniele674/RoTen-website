package daniele.Taglia;

import daniele.Categoria.Categoria;
import daniele.Components.Paginator;

import java.util.List;
import java.util.Optional;

public interface TagliaDao <E extends Exception>{

    List<Taglia> prelevaTaglie(Paginator paginator) throws E;

    List<Taglia> prelevaTaglieSolo() throws E;

    int countAll() throws E;

    Optional<Taglia> prelevaTaglia(int idTaglia) throws E;

    boolean creaTaglia(Taglia taglia) throws E;

    boolean aggiornaTaglia(Taglia taglia) throws E;
}

