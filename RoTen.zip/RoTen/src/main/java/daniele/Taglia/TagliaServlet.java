package daniele.Taglia;

import daniele.Categoria.Categoria;
import daniele.Categoria.CategoriaFormMapper;
import daniele.Components.Alert;
import daniele.Components.Paginator;
import daniele.http.CommonValidator;
import daniele.http.Controller;
import daniele.http.InvalidRequestException;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@WebServlet(name = "TagliaServlet", value = "/taglie/*")

public class TagliaServlet extends Controller {

    private TagliaDao<SQLException> tagliaDao;

    public void init() throws ServletException{
        super.init();
        tagliaDao = new SqlTagliaDao(source);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch(path){
                case "/":
                    authorize(request.getSession(false));
                    validate((CommonValidator.validatePage(request)));
                    int page = parsePage(request);
                    Paginator paginator = new Paginator(page, 10);
                    List<Taglia> taglie = tagliaDao.prelevaTaglie(paginator);
                    int size = tagliaDao.countAll();
                    request.setAttribute("taglie", taglie);
                    request.setAttribute("pages", paginator.getPages(size));
                    request.getRequestDispatcher(view("crm/taglie")).forward(request,response);
                    break;
                case "/show":
                    authorize(request.getSession(false));
                    validate(CommonValidator.validateId(request));
                    int id = Integer.parseInt(request.getParameter("id"));
                    Optional<Taglia> optTaglia = tagliaDao.prelevaTaglia(id);
                    if(optTaglia.isPresent()){
                        request.setAttribute("taglia", optTaglia.get());
                        request.getRequestDispatcher(view("crm/taglia")).forward(request,response);
                    }else{
                        notFound();
                    }
                    break;
                case "/create":
                    authorize(request.getSession(false));
                    request.getRequestDispatcher(view("crm/taglia")).forward(request,response);
                    break;
                default:
                    notFound();
            }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch(path){
                case "/create":
                    authorize(request.getSession(false));
                    request.setAttribute("back", view("crm/taglia"));
                    validate(TagliaValidator.validateForm(request, false));
                    Taglia taglia = new TagliaFormMapper().map(request, false);
                    if(tagliaDao.creaTaglia(taglia)){
                        request.setAttribute("alert", new Alert(List.of("Taglia Creata!"), "successo"));
                        response.setStatus(HttpServletResponse.SC_CREATED);
                        request.getRequestDispatcher(view("crm/taglia")).forward(request,response);
                    }else{
                        internalError();
                    }
                    break;
                case "/update":
                    request.setCharacterEncoding("UTF-8");
                    authorize(request.getSession(false));        //autorizzare admin
                    request.setAttribute("back", view("crm/taglia"));
                    validate(TagliaValidator.validateForm(request, true));
                    Taglia updatedTaglia = new TagliaFormMapper().map(request, true);
                    request.setAttribute("taglia", updatedTaglia);
                    if(tagliaDao.aggiornaTaglia(updatedTaglia)){
                        request.setAttribute("alert", new Alert(List.of("Taglia Aggiornata!"), "successo"));
                        request.getRequestDispatcher(view("crm/taglia")).forward(request,response);
                    }else{
                        internalError();
                    }
                    break;
                default:
                    notAllowed();
            }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }
}
