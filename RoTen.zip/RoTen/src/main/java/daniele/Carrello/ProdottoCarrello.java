package daniele.Carrello;

import daniele.Prodotto.Prodotto;

public class ProdottoCarrello {
    public ProdottoCarrello(Prodotto prodotto, int quantita) {
        this.prodotto = prodotto;
        this.quantita = quantita;
    }

    public Prodotto getProdotto() {
        return prodotto;
    }

    public int getQuantita() {
        return quantita;
    }

    public double totale(){
        return prodotto.getPrezzoProdotto() * quantita;
    }


    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }

    private final Prodotto prodotto;
    private int quantita;
}
