package daniele.Carrello;

import daniele.Carrello.Carrello;
import daniele.Prodotto.Prodotto;
import daniele.Prodotto.ProdottoDao;
import daniele.Prodotto.SqlProdottoDao;
import daniele.Taglia.Taglia;
import daniele.http.CommonValidator;
import daniele.http.Controller;
import daniele.http.InvalidRequestException;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

@WebServlet(name = "CarrelloServlet", value = "/carrelli/*")
public class CarrelloServlet extends Controller {

    private ProdottoDao<SQLException> prodottoDao;

    public void init() throws ServletException{
        super.init();
        prodottoDao = new SqlProdottoDao(source);
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch (path){
                case "/show":
                    request.getRequestDispatcher(view("site/carrello")).forward(request,response);
                    break;
                default:
                    notFound();
            }
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch (path){
                case "/add":
                    request.setAttribute("back", view("site/details"));
                    validate(CarrelloValidator.validateProdotto(request));
                    int id = Integer.parseInt(request.getParameter("id"));
                    Optional<Prodotto> optProdotto = prodottoDao.prelevaProdottoConTaglie(id);
                    if(optProdotto.isPresent()){
                        int quantita = Integer.parseInt(request.getParameter("quantita"));
                        String primitivo = request.getParameter("taglia");
                        String[] parametri = primitivo.split(",");
                        Taglia taglia = new Taglia();
                        taglia.setTipo(parametri[0]);
                        taglia.setNumero(parametri[1]);
                        taglia.setIdTaglia(Integer.parseInt(parametri[2]));
                        optProdotto.get().setTaglie(new ArrayList<>());
                        optProdotto.get().getTaglie().add(taglia);
                        if(request.getSession(false).getAttribute("utenteCarrello") == null){
                            request.getSession(false).setAttribute("utenteCarrello", new Carrello(new ArrayList<>()));
                        }
                        getSessionCart(request.getSession(false)).aggiungiProdotto(optProdotto.get(), quantita);
                        response.sendRedirect("../prodotti/details?id=" + optProdotto.get().getIdProdotto());
                    }else{
                        notFound();
                    }
                    break;
                case "/remove":
                    validate(CommonValidator.validateId(request));
                    int removeId = Integer.parseInt(request.getParameter("id"));
                    String tipo_taglia = request.getParameter("tipo_taglia");
                    String numero_taglia = request.getParameter("numero_taglia");
                    Taglia taglia = new Taglia();
                    taglia.setTipo(tipo_taglia);
                    taglia.setNumero(numero_taglia);
                    if(getSessionCart(request.getSession(false)).rimuoviProdotto(removeId, taglia)){
                        response.sendRedirect("../carrelli/show");
                    }else{
                        notFound();
                    }
                    break;
                default:
                    notAllowed();
            }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }
}
