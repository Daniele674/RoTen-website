package daniele.Carrello;

import daniele.http.RequestValidator;

import javax.servlet.http.HttpServletRequest;
import java.util.regex.Pattern;

public class CarrelloValidator{
    static RequestValidator validateProdotto(HttpServletRequest request){
        RequestValidator validator = new RequestValidator(request);
        validator.assertInt("id", "Id deve essere un intero");
        validator.assertInt("quantita", "Quantita deve essere un intero");
        return validator;
    }
}
