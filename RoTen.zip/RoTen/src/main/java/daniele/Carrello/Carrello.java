package daniele.Carrello;

import daniele.Prodotto.Prodotto;
import daniele.Taglia.Taglia;

import java.util.List;
import java.util.Optional;

public class Carrello {

    public Carrello(List<ProdottoCarrello> prodotti) {
        this.prodotti = prodotti;
    }

    public double totale(){
        double totale = 0.0;

        for(ProdottoCarrello prodotto : prodotti){
            totale += prodotto.totale();
        }
        return totale;
    }

    public List<ProdottoCarrello> getProdotti() {
        return prodotti;
    }

    public void setProdotti(List<ProdottoCarrello> prodotti) {
        this.prodotti = prodotti;
    }

    public boolean aggiungiProdotto(Prodotto prodotto, int quantita){
        Optional<ProdottoCarrello> optProdotto = trova(prodotto.getIdProdotto(), prodotto.getTaglie().get(0));
        if(optProdotto.isPresent()){
            optProdotto.get().setQuantita(quantita);
            return true;
        }else{
            return prodotti.add(new ProdottoCarrello(prodotto, quantita));
        }
    }

   /* public boolean aggiungiProdottoOrdine(Prodotto prodotto, int quantita){
        Optional<ProdottoCarrello> optProdotto = trovaOrdine(prodotto.getIdProdotto());
        if(optProdotto.isPresent()){
            optProdotto.get().setQuantita(quantita);
            return true;
        }else{
            return prodotti.add(new ProdottoCarrello(prodotto, quantita));
        }
    }*/

    public Optional<ProdottoCarrello> trova(int id, Taglia taglia){
        ProdottoCarrello prodottoCarrello = null;
        for(ProdottoCarrello prod: prodotti) {
            if (prod.getProdotto().getIdProdotto() == id && prod.getProdotto().getTaglie().get(0).equals(taglia)) {
                prodottoCarrello = prod;
            }
        }
        return Optional.ofNullable(prodottoCarrello);
    }

    /*public Optional<ProdottoCarrello> trovaOrdine(int id){
        return prodotti.stream().filter(it -> it.getProdotto().getIdProdotto() == id).findFirst();
    }*/

    public boolean rimuoviProdotto(int id, Taglia taglia){
        //return prodotti.removeIf(it -> it.getProdotto().getIdProdotto() == id);
        for (ProdottoCarrello prodotto: prodotti){
            if(prodotto.getProdotto().getIdProdotto() == id && prodotto.getProdotto().getTaglie().get(0).equals(taglia)){
                prodotti.remove(prodotto);
                return true;
            }
        }
        return false;
    }

    public int quantita(){
        return prodotti.stream().mapToInt(ProdottoCarrello::getQuantita).reduce(0, Integer::sum);
    }

    public void resetCarrello(){
        prodotti.clear();
    }

    private List<ProdottoCarrello> prodotti;
}
