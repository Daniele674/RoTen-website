package daniele.utility;

import javax.sql.DataSource;

public abstract class SqlDao{

    protected final DataSource source;          //Variabile in sola lettura che funge da connessione alla base di dati

    public SqlDao(DataSource source) {
        this.source = source;
    }
}
