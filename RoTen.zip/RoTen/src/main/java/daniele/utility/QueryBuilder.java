package daniele.utility;

import daniele.search.Condition;
import daniele.search.Operator;

import java.util.List;
import java.util.StringJoiner;

public class QueryBuilder {
    private final String table,alias;
    private final StringBuilder query;
    private static final String QM="?";

    public QueryBuilder (String table, String alias){
        this.table = table;
        this.alias = alias;
        this.query = new StringBuilder();
    }

    public String generateQuery() {     //ritorna la stringa della query e resetta la lunghezza della costante
        String generatedQuery = query.toString();
        query.setLength(0);
        return generatedQuery;
    }

    public QueryBuilder select(String... fields){
        query.append("SELECT ");
        if(fields.length == 0){         //se non inseriamo parametri facciamo una SELECT ALL
            query.append('*');
        }else{
            StringJoiner commaJoiner = new StringJoiner(",");       //creiamo un delimitatore
            for(String field : fields){
                commaJoiner.add(String.format("%s.%s", alias, field));      //inseriamo ogni field separato dalla virgola
            }
            query.append(commaJoiner.toString());           //creiamo la stringa finale
        }
        query.append(" FROM ").append(table).append(" AS ").append(alias);      //from dalla tabella
        return this;
    }

    public QueryBuilder where(String condition){        //aggiungiamo una WHERE
        query.append(" WHERE ").append(condition);
        return this;
    }

    public QueryBuilder where(){
        query.append(" WHERE ");
        return this;
    }

    public QueryBuilder insert(String... fields){
        query.append("INSERT INTO ").append(table).append(' ');
        StringJoiner commaJoiner = new StringJoiner(",", "(",")");  //scegliamo le colonne da inserire attraverso i parametri
        for(String field : fields){
            commaJoiner.add(field);
        }
        query.append(commaJoiner.toString());
        query.append(" VALUES ");
        int numberOfFields = fields.length;     //contiamo i campi passati alla funzione per scrivere lo stesso numero di values
        StringJoiner qmJoiner = new StringJoiner(",", "(",")");
        do{
            qmJoiner.add(QM);
            numberOfFields--;
        }while(numberOfFields != 0);

        query.append(qmJoiner.toString());          //creo la stringa finale
        return this;
    }

    public QueryBuilder delete(){           //faccio una DELETE
        query.append("DELETE FROM ").append(table);
        return this;
    }

    public QueryBuilder update(String... fields){
        query.append("UPDATE ").append(table);
        query.append(" SET ");
        StringJoiner commaJoiner = new StringJoiner(",");
        for(String field : fields){
            commaJoiner.add(String.format("%s = %s", field, QM));
        }
        query.append(commaJoiner.toString());
        return this;
    }

    public QueryBuilder limit(boolean withOffset){
        query.append(" LIMIT ").append(QM);
        if(withOffset){
            query.append(',').append(QM);
        }
        return this;
    }

    public QueryBuilder innerJoin(String joinedTable, String joinedAlias){
        query.append(" INNER JOIN ").append(joinedTable).append(' ').append(joinedAlias);
        return this;
    }

    public QueryBuilder outerJoin(boolean isLeft, String joinedTable, String joinedAlias){
        String direction = isLeft ? " LEFT JOIN" : " RIGHT JOIN";
        query.append(direction).append(' ').append(joinedTable).append(' ').append(joinedAlias);
        return this;
    }

    public QueryBuilder on(String condition){
        query.append(" ON ").append(condition);
        return this;
    }

    public QueryBuilder search(List<Condition> conditions){
        StringJoiner searchJoiner = new StringJoiner(" AND ");
        for(Condition cn : conditions){
                searchJoiner.add(String.format("%s.%s%s", alias, cn.toString(), QM));
        }
        query.append(searchJoiner);
        return this;
    }

    public QueryBuilder count(String name){
        query.append("SELECT COUNT(*) AS ")
                .append(name)
                .append(" FROM ")
                .append(this.table);
        return this;
    }

    public QueryBuilder sum(String name){
        query.append("SELECT SUM(")
                .append(name)
                .append(") AS ")
                .append(name)
                .append(" FROM ")
                .append(this.table);
        return this;
    }
}
