package daniele.Ordine;


import daniele.utility.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;

public class OrdineExtractor implements ResultSetExtractor<Ordine> {

    public Ordine extract(ResultSet resultset) throws SQLException {
        Ordine ordine = new Ordine();
        ordine.setIdOrdine(resultset.getInt("ord.idOrdine"));
        ordine.setDataOrdine(resultset.getDate("ord.dataOrdine").toLocalDate());
        ordine.setTotale(resultset.getDouble("ord.totale"));
        return ordine;
    }
}