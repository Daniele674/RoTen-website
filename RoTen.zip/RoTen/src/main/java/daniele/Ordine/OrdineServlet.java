package daniele.Ordine;

import daniele.Components.Paginator;
import daniele.Utente.Utente;
import daniele.http.CommonValidator;
import daniele.http.Controller;
import daniele.http.InvalidRequestException;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@WebServlet(name = "OrdineServlet", value = "/ordini/*")
public class OrdineServlet extends Controller {

    private OrdineDao<SQLException> ordineDao;

    public void init() throws ServletException{
        super.init();
        ordineDao = new SqlOrdineDao(source);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch (path){
                case "/":           //trova ordini (admin)
                    authorize(request.getSession(false));
                    validate(CommonValidator.validatePage(request));
                    int intPage = parsePage(request);
                    int size = ordineDao.countAll();
                    Paginator paginator = new Paginator(intPage, 50);
                    List<Ordine> ordini = ordineDao.prelevaOrdini(paginator);
                    request.setAttribute("ordini", ordini);
                    request.setAttribute("pages", paginator.getPages(size));
                    request.getRequestDispatcher(view("crm/ordini")).forward(request,response);
                    break;
                case "/show":
                    authorize(request.getSession(false));
                    validate(CommonValidator.validateId(request));
                    int id = Integer.parseInt(request.getParameter("id"));
                    Optional<Ordine> optOrdine = ordineDao.prelevaOrdineConProdotti(id);
                    if(optOrdine.isPresent()){
                        request.setAttribute("ordine", optOrdine.get());
                        request.getRequestDispatcher(view("crm/ordine")).forward(request,response);
                    }else{
                        notFound();
                    }
                    break;
                case "/profile":
                    HttpSession accSession = request.getSession(false);
                    authenticate(accSession);
                    int accId = getUtenteSession(accSession).getId();
                    List<Ordine> ordineList = ordineDao.prelevaOrdiniConProdotti(accId);
                    request.setAttribute("ordini", ordineList);
                    request.getRequestDispatcher(view("site/profile")).forward(request,response);
                    break;
            }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try{
            String path = getPath(request);
            switch(path){
                case "/create":     //crea ordine cliente
                    request.setAttribute("back", view("site/signin"));
                    HttpSession session = request.getSession(false);
                    authenticate(session);
                    Ordine ordineCliente = new Ordine();
                    Utente utente = new Utente();
                    utente.setIdUtente(getUtenteSession(session).getId());
                    ordineCliente.setUtente(utente);
                    ordineCliente.setCarrello(getSessionCart(session));
                    ordineCliente.setTotale(getSessionCart(session).totale());
                    ordineCliente.setDataOrdine(LocalDate.now());
                    if(ordineDao.creaOrdine(ordineCliente)){
                        getSessionCart(session).resetCarrello();
                        response.sendRedirect("../ordini/profile");
                    }else{
                        internalError();
                    }
                    break;
                default:
                    notAllowed();
            }
        }catch(SQLException ex){
            log(ex.getMessage());
        }catch(InvalidRequestException e){
            log(e.getMessage());
            e.handle(request, response);
        }
    }
}
