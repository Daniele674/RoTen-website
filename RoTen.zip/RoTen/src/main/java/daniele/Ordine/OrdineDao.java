package daniele.Ordine;

import daniele.Components.Paginator;

import java.util.List;
import java.util.Optional;

public interface OrdineDao<E extends Exception> {

    Optional<Ordine> prelevaOrdine(int idOrdine) throws E;

    List<Ordine> prelevaOrdini(Paginator paginator) throws E;

    Optional<Ordine> prelevaOrdineConProdotti(int idUtente) throws E;

    List<Ordine> prelevaOrdiniConProdotti(int idUtente) throws E;

    int countAll() throws E;

    int sumTotaleOrdini() throws E;

    boolean creaOrdine(Ordine ordine) throws E;
}
