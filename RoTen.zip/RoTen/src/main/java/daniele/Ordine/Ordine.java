package daniele.Ordine;

import daniele.Carrello.Carrello;
import daniele.Utente.Utente;

import java.time.LocalDate;

public class Ordine {

    public Ordine() {
        super();
    }

    public int getIdOrdine() {
        return idOrdine;
    }

    public void setIdOrdine(int idOrdine) {
        this.idOrdine = idOrdine;
    }

    public double getTotale() {
        return totale;
    }

    public void setTotale(double totale) {
        this.totale = totale;
    }

    public LocalDate getDataOrdine() {
        return dataOrdine;
    }

    public void setDataOrdine(LocalDate dataOrdine) {
        this.dataOrdine = dataOrdine;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public Carrello getCarrello() {
        return carrello;
    }

    public void setCarrello(Carrello carrello) {
        this.carrello = carrello;
    }

    public int entries(){
        return carrello.getProdotti().size();
    }

    private int idOrdine;
    private double totale;
    private LocalDate dataOrdine;
    private Utente utente;
    private Carrello carrello;
}
