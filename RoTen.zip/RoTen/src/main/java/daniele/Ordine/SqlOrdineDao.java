package daniele.Ordine;

import daniele.Carrello.Carrello;
import daniele.Carrello.ProdottoCarrello;
import daniele.Prodotto.Prodotto;
import daniele.Prodotto.ProdottoExtractor;
import daniele.Components.Paginator;
import daniele.Taglia.TagliaExtractor;
import daniele.utility.QueryBuilder;
import daniele.utility.SqlDao;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.*;

public class SqlOrdineDao extends SqlDao implements OrdineDao<SQLException> {
    public SqlOrdineDao(DataSource source) {
        super(source);
    }

    public Optional<Ordine> prelevaOrdine(int idOrdine) throws SQLException {
        try (Connection conn = source.getConnection()) {
            QueryBuilder queryBuilder = new QueryBuilder("ordine", "ord");
            String query = queryBuilder.select().where("ord.idOrdine=?").generateQuery();
            try (PreparedStatement ps = conn.prepareStatement(query)) {               //passo la query al preparedstatement
                ps.setInt(1, idOrdine);
                ResultSet set = ps.executeQuery();
                Ordine ordine = null;
                if (set.next()) {
                    ordine = new OrdineExtractor().extract(set);
                }
                return Optional.ofNullable(ordine);
            }
        }
    }

    public List<Ordine> prelevaOrdini(Paginator paginator) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("ordine", "ord");
            String query = queryBuilder.select().limit(true).generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ps.setInt(1, paginator.getOffset());
                ps.setInt(2, paginator.getLimit());
                ResultSet set = ps.executeQuery();
                OrdineExtractor ordineExtractor = new OrdineExtractor();
                List<Ordine> ordini = new ArrayList<>();
                while(set.next()){
                    ordini.add(ordineExtractor.extract(set));
                }
                return ordini;
            }
        }
    }

    public Optional<Ordine> prelevaOrdineConProdotti(int idOrdine) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("ordine", "ord");
            String query = queryBuilder.select().innerJoin("ordine_prodotto", "op").on("op.ordine_fk = ord.idOrdine")
                    .innerJoin("prodotto", "pro").on("op.prodotto_fk = pro.idProdotto")
                    .where("ordine.idOrdine = ?").generateQuery();

            try(PreparedStatement ps = conn.prepareStatement(query)){
                ps.setInt(1, idOrdine);
                ResultSet set = ps.executeQuery();
                OrdineExtractor ordineExtractor = new OrdineExtractor();
                ProdottoExtractor prodottoExtractor = new ProdottoExtractor();
                Ordine ordine = null;
                if (set.next()){
                    ordine = ordineExtractor.extract(set);
                    ordine.setCarrello(new Carrello(new ArrayList<>()));
                    Prodotto prodotto = prodottoExtractor.extract(set);
                    ordine.getCarrello().aggiungiProdotto(prodotto, set.getInt("op.quantita"));
                    while (set.next()){
                        prodotto = prodottoExtractor.extract(set);
                        ordine.getCarrello().aggiungiProdotto(prodotto, set.getInt("op.quantita"));
                    }
                }
                return Optional.ofNullable(ordine);
            }
        }
    }

    @Override
    public List<Ordine> prelevaOrdiniConProdotti(int idUtente) throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("ordine_prodotto", "op");
            String query = queryBuilder.select().innerJoin("ordine", "ord").on("op.ordine_fk = ord.idOrdine")
                    .innerJoin("prodotto","pro").on("op.prodotto_fk = pro.idProdotto")
                    .innerJoin("taglia", "tag").on("tag.idTaglia=op.taglia_fk")
                    .where("ord.utente_fk = ?").generateQuery();

            try(PreparedStatement ps = conn.prepareStatement(query)){
                ps.setInt(1, idUtente);
                ResultSet set = ps.executeQuery();
                Map<Integer, Ordine> ordineMap = new HashMap<>();
                OrdineExtractor ordineExtractor = new OrdineExtractor();
                ProdottoExtractor prodottoExtractor = new ProdottoExtractor();
                TagliaExtractor tagliaExtractor = new TagliaExtractor();

                while(set.next()){
                    int idOrdine = set.getInt("ord.idOrdine");
                    if(!ordineMap.containsKey(idOrdine)){
                        Ordine ordine = ordineExtractor.extract(set);
                        ordine.setCarrello(new Carrello(new ArrayList<>()));
                        ordineMap.put(idOrdine,ordine);
                        Prodotto prodotto = prodottoExtractor.extract(set);
                        prodotto.setTaglie(new ArrayList<>());
                        prodotto.getTaglie().add(tagliaExtractor.extract(set));
                        ordineMap.get(idOrdine).getCarrello().aggiungiProdotto(prodotto, set.getInt("op.quantita"));
                    }else{
                        Prodotto prodotto1 = prodottoExtractor.extract(set);
                        prodotto1.setTaglie(new ArrayList<>());
                        prodotto1.getTaglie().add(tagliaExtractor.extract(set));
                        ordineMap.get(idOrdine).getCarrello().aggiungiProdotto(prodotto1, set.getInt("op.quantita"));
                    }
                }
                return new ArrayList<>(ordineMap.values());
            }
        }
    }

    @Override
    public int countAll() throws SQLException {
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("ordine", "ord");
            String query = queryBuilder.count("totaleOrdini").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                int size = 0;
                if(set.next()){
                    size = set.getInt("totaleOrdini");
                }
                return size;
            }
        }
    }

    public int sumTotaleOrdini() throws SQLException{
        try(Connection conn = source.getConnection()){
            QueryBuilder queryBuilder = new QueryBuilder("ordine", "ord");
            String query = queryBuilder.sum("totale").generateQuery();
            try(PreparedStatement ps = conn.prepareStatement(query)){
                ResultSet set = ps.executeQuery();
                int size = 0;
                if(set.next()){
                    size = set.getInt("totale");
                }
                return size;
            }
        }
    }

    public boolean creaOrdine(Ordine ordine) throws SQLException {
        try(Connection conn = source.getConnection()){
            conn.setAutoCommit(false);
            QueryBuilder queryBuilder = new QueryBuilder("ordine", "ord");
            String query = queryBuilder.insert("totale", "dataOrdine", "utente_fk").generateQuery();
            QueryBuilder queryBuilder1 = new QueryBuilder("ordine_prodotto", "op");
            String query1 = queryBuilder1.insert("prodotto_fk","ordine_fk", "taglia_fk", "quantita").generateQuery();

            try(
                    PreparedStatement ps = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
                    PreparedStatement psAssoc = conn.prepareStatement(query1);
            ){
                ps.setDouble(1,Math.round((ordine.getTotale()) * 100.0) / 100.0);
                ps.setDate(2, Date.valueOf(ordine.getDataOrdine()));
                ps.setInt(3,ordine.getUtente().getIdUtente());
             int rows = ps.executeUpdate();
             ResultSet setId = ps.getGeneratedKeys();
             setId.next();
             int id = setId.getInt(1);
             ordine.setIdOrdine(id);
             int total = rows;
             for(ProdottoCarrello prodotto : ordine.getCarrello().getProdotti()){
                 psAssoc.setInt(1, prodotto.getProdotto().getIdProdotto());
                 psAssoc.setInt(2, ordine.getIdOrdine());
                 psAssoc.setInt(3, prodotto.getProdotto().getTaglie().get(0).getIdTaglia());
                 psAssoc.setInt(4, prodotto.getQuantita());
                 total += psAssoc.executeUpdate();
             }
             if(total == (rows + ordine.entries())){
                 conn.commit();
                 conn.setAutoCommit(true);
                 return true;
             }else{
                 conn.rollback();       //annulla tutte le operazioni
                 conn.setAutoCommit(true);
                 return false;
             }
            }
        }
    }
}
