window.addEventListener('scroll', function(){
    if(window.scrollY > 0) {
        document.getElementById("divToShowHide").classList.add('linea-ombra');
    }else{
        document.getElementById('divToShowHide').classList.remove('linea-ombra');
    }});

const form = document.getElementById("credenziali");
if(form){
    validateForm(form);
}