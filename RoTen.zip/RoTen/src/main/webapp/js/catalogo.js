ajax({
    url: '../categorie/api',
    method: 'GET',
    success: function (data){
        const select = document.getElementById("idCategoria");
        for(let index in data.categorie){
            let option = document.createElement("option");
            let optionText = document.createTextNode(data.categorie[index].label);
            option.setAttribute("value", data.categorie[index].id);
            option.appendChild(optionText);
            select.appendChild(option);
        }
    },
    error: function (err){
        console.error(err);
    }
});

